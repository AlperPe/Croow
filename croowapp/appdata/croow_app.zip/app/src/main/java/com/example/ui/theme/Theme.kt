package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CroowColorScheme = darkColorScheme(
  primary = CroowGreen,
  onPrimary = Color.Black,
  primaryContainer = Color(0xFF0D2818),
  onPrimaryContainer = CroowGreen,
  secondary = CroowAccentBlue,
  onSecondary = Color.Black,
  secondaryContainer = Color(0xFF13233A),
  onSecondaryContainer = CroowAccentBlue,
  tertiary = CroowPurple,
  onTertiary = Color.White,
  tertiaryContainer = Color(0xFF2E1065),
  onTertiaryContainer = CroowPurpleLight,
  background = CroowBg,
  onBackground = CroowTextMain,
  surface = CroowSurface,
  onSurface = CroowTextMain,
  surfaceVariant = CroowSurfaceVariant,
  onSurfaceVariant = CroowTextMuted,
  error = CroowError,
  onError = Color.Black
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Croow is primarily dark/cyber aesthetic
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = CroowColorScheme,
    typography = Typography,
    content = content
  )
}
