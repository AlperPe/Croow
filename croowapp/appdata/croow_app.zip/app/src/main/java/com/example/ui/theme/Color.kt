package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CROOW Cyber & Dark Vault Palette
val CroowBg = Color(0xFF06080D)
val CroowBgDarker = Color(0xFF030407)
val CroowSurface = Color(0xFF0C1017)
val CroowSurfaceVariant = Color(0xFF141A24)
val CroowBorder = Color(0x24FFFFFF)
val CroowBorderHighlight = Color(0x6600E676)

val CroowGreen = Color(0xFF00E676)
val CroowGreenMuted = Color(0xFF2EA043)
val CroowAccentBlue = Color(0xFF58A6FF)
val CroowPurple = Color(0xFF7C3AED)
val CroowPurpleLight = Color(0xFFA78BFA)

val CroowTextMain = Color(0xFFF0F6FC)
val CroowTextMuted = Color(0xFF8B949E)
val CroowError = Color(0xFFFF7B72)
val CroowWarning = Color(0xFFF59E0B)
