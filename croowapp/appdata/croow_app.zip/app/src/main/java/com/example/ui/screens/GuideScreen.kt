package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.model.AppIdea

val sampleIdeas = listOf(
  AppIdea(
    id = "habits",
    title = "Alışkanlık & Rutin Takipçisi",
    category = "Üretkenlik",
    description = "Günlük hedefler, seri (streak) sayacı ve kategoriye göre düzenleme.",
    samplePrompt = "Bana günlük alışkanlıklarımı ve rutinlerimi takip edebileceğim, tamamlama serileri (streaks), kategori filtreleri ve haftalık ilerleme çubuğu olan şık bir Alışkanlık Takipçisi uygulaması yap.",
    iconEmoji = "🎯",
    badge = "Popüler"
  ),
  AppIdea(
    id = "finance",
    title = "Gelir-Gider & Bütçe Yönetimi",
    category = "Finans",
    description = "Harcama ekleme, bütçe limiti, kategori grafiği ve bakiye özeti.",
    samplePrompt = "Kişisel finans yönetimi için gelir ve giderlerimi kolayca kaydedebileceğim, kategori bazlı harcama dağılımını gösteren ve aylık bütçe özeti sunan bir uygulama yap.",
    iconEmoji = "💰",
    badge = "Önerilen"
  ),
  AppIdea(
    id = "weather",
    title = "Hava Durumu & Kıyafet Önerisi",
    category = "Yaşam",
    description = "Günlük ve haftalık hava tahmini, sıcaklığa göre akıllı giyim tavsiyesi.",
    samplePrompt = "Şehir seçebildiğim, anlık hava durumu ve 5 günlük tahmin gösteren, hava koşullarına göre dışarı çıkarken ne giyilmesi gerektiğini öneren şık bir hava durumu uygulaması hazırla.",
    iconEmoji = "🌦️"
  ),
  AppIdea(
    id = "fitness",
    title = "Fitness & Antrenman Günlüğü",
    category = "Sağlık",
    description = "Egzersiz programı, set/tekrar sayacı, mola kronometresi ve kalori hedefi.",
    samplePrompt = "Spor salonunda ve evde antrenmanlarımı kaydedebileceğim, set ve ağırlık takibi yapan, dinlenme süresi için kronometresi olan bir fitness günlüğü uygulaması yap.",
    iconEmoji = "🏋️"
  ),
  AppIdea(
    id = "recipes",
    title = "Tarifler & Akıllı Alışveriş",
    category = "Yemek",
    description = "Lezzetli yemek tarifleri, favoriler ve malzemeleri tek tıkla sepete ekleme.",
    samplePrompt = "Kategoriye göre yemek tarifleri bulabileceğim, adım adım yapılışını gösteren ve malzemeleri anında alışveriş listeme dönüştüren bir yemek tarifi uygulaması oluştur.",
    iconEmoji = "🥗"
  ),
  AppIdea(
    id = "notes",
    title = "Fikir Defteri & Sesli Notlar",
    category = "Araçlar",
    description = "Hızlı not alma, renkli etiketler, arama ve yapılacaklar kontrol listesi.",
    samplePrompt = "Hızlıca renkli notlar alabileceğim, yapılacaklar listesi (checkbox) oluşturabileceğim ve notlarım içinde arama yapabileceğim minimalist bir not defteri uygulaması hazırla.",
    iconEmoji = "📝"
  )
)

@Composable
fun GuideScreen(
  onShowSnackbar: (String) -> Unit,
  onNavigateToPlayground: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var selectedCategory by remember { mutableStateOf("Tümü") }
  var selectedIdeaForDialog by remember { mutableStateOf<AppIdea?>(null) }

  val categories = listOf("Tümü", "Üretkenlik", "Finans", "Yaşam", "Sağlık", "Yemek", "Araçlar")
  val filteredIdeas = if (selectedCategory == "Tümü") {
    sampleIdeas
  } else {
    sampleIdeas.filter { it.category == selectedCategory }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("guide_screen_lazy_column"),
    contentPadding = PaddingValues(bottom = 96.dp)
  ) {
    // Hero Banner
    item {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .background(
            Brush.verticalGradient(
              colors = listOf(
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f),
                MaterialTheme.colorScheme.background
              )
            )
          )
          .padding(horizontal = 20.dp, vertical = 24.dp)
      ) {
        Column {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Box(
              modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.RocketLaunch,
                contentDescription = "Roket",
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(28.dp)
              )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
              Text(
                text = "Nasıl Çalışır?",
                style = MaterialTheme.typography.headlineMedium.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 26.sp
                ),
                color = MaterialTheme.colorScheme.onBackground
              )
              Text(
                text = "Android AI Builder Rehberi",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(18.dp))

          Card(
            colors = CardDefaults.cardColors(
              containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(18.dp)) {
              Text(
                text = "👋 Yapay zekaya sadece ne istediğinizi söyleyin!",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.primary
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "Bu platformda sıfırdan kod yazmanıza gerek yok. Sohbet kutusuna Türkçe veya İngilizce istediğiniz uygulamayı, istediğiniz ekranları ve özellikleri anlatmanız yeterlidir.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 22.sp
              )
            }
          }
        }
      }
    }

    // 3 Step Guide
    item {
      Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
        Text(
          text = "3 Kolay Adımda Geliştirme",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(14.dp))

        StepCard(
          stepNumber = "1",
          title = "Ne İstediğinizi Yazın",
          description = "Sohbet ekranına yapmak istediğiniz uygulamayı ve fonksiyonları yazın (Örn: 'Bana bir yapılacaklar listesi yap').",
          badgeColor = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(10.dp))

        StepCard(
          stepNumber = "2",
          title = "Kod & Ekranlar Otomatik İnşa Edilsin",
          description = "Yapay zeka tüm Jetpack Compose ekranlarını, butonları, veri akışını ve tasarımlarını anında yazar.",
          badgeColor = MaterialTheme.colorScheme.secondary
        )

        Spacer(modifier = Modifier.height(10.dp))

        StepCard(
          stepNumber = "3",
          title = "Canlı Emülatörde Test Edin & Geliştirin",
          description = "Sağ taraftaki emülatörde uygulamanız canlı çalışır. 'Şu rengi değiştir', 'Yeni sayfa ekle' diyerek dilediğiniz gibi güncelleyin.",
          badgeColor = MaterialTheme.colorScheme.tertiary
        )
      }
    }

    // Quick Live Demo CTA
    item {
      ElevatedCard(
        onClick = onNavigateToPlayground,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(
          containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp, vertical = 8.dp)
          .testTag("cta_try_playground_button")
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onPrimary
            )
          }
          Spacer(modifier = Modifier.width(14.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Canlı Örnekleri Dene",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Text(
              text = "Compose bileşenleri, sayaç ve görev yöneticisi demosu",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
          }
          Icon(
            imageVector = Icons.Default.Send,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary
          )
        }
      }
    }

    // Sample Prompts Section
    item {
      Column(modifier = Modifier.padding(top = 16.dp)) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Örnek Uygulama İstekleri",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "Aşağıdaki fikirlerden birine dokunup kopyalayabilir ve sohbete gönderebilirsiniz:",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.padding(horizontal = 20.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Categories Chips
        LazyRow(
          contentPadding = PaddingValues(horizontal = 20.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(categories) { cat ->
            FilterChip(
              selected = (selectedCategory == cat),
              onClick = { selectedCategory = cat },
              label = { Text(cat) },
              modifier = Modifier.testTag("category_chip_$cat")
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
      }
    }

    // List of Idea Cards
    items(filteredIdeas, key = { it.id }) { idea ->
      IdeaCard(
        idea = idea,
        onCopyPrompt = { prompt ->
          copyToClipboard(context, prompt)
          onShowSnackbar("Prompt panoya kopyalandı! Şimdi sohbete yapıştırabilirsiniz.")
        },
        onCardClick = {
          selectedIdeaForDialog = idea
        },
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
      )
    }

    // Prompt Dialog
    item {
      selectedIdeaForDialog?.let { idea ->
        AlertDialog(
          onDismissRequest = { selectedIdeaForDialog = null },
          title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(idea.iconEmoji, fontSize = 24.sp)
              Spacer(modifier = Modifier.width(8.dp))
              Text(idea.title)
            }
          },
          text = {
            Column {
              Text(
                text = idea.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "Örnek Prompt:",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary
              )
              Spacer(modifier = Modifier.height(6.dp))
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(
                  text = idea.samplePrompt,
                  style = MaterialTheme.typography.bodySmall,
                  modifier = Modifier.padding(12.dp),
                  lineHeight = 18.sp
                )
              }
            }
          },
          confirmButton = {
            Button(
              onClick = {
                copyToClipboard(context, idea.samplePrompt)
                onShowSnackbar("Prompt kopyalandı! Sohbete yapıştırıp gönderebilirsiniz.")
                selectedIdeaForDialog = null
              },
              modifier = Modifier.testTag("dialog_copy_button")
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Kopyala")
            }
          },
          dismissButton = {
            TextButton(onClick = { selectedIdeaForDialog = null }) {
              Text("Kapat")
            }
          }
        )
      }
    }
  }
}

@Composable
fun StepCard(
  stepNumber: String,
  title: String,
  description: String,
  badgeColor: Color,
  modifier: Modifier = Modifier
) {
  OutlinedCard(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.outlinedCardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    modifier = modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.Top
    ) {
      Box(
        modifier = Modifier
          .size(34.dp)
          .clip(CircleShape)
          .background(badgeColor),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = stepNumber,
          color = Color.White,
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp
        )
      }
      Spacer(modifier = Modifier.width(14.dp))
      Column {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          lineHeight = 18.sp
        )
      }
    }
  }
}

@Composable
fun IdeaCard(
  idea: AppIdea,
  onCopyPrompt: (String) -> Unit,
  onCardClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  ElevatedCard(
    onClick = onCardClick,
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.elevatedCardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
    modifier = modifier
      .fillMaxWidth()
      .testTag("idea_card_${idea.id}")
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = idea.iconEmoji, fontSize = 24.sp)
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = idea.title,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = idea.category,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }

        if (idea.badge != null) {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.secondaryContainer
          ) {
            Text(
              text = idea.badge,
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
              color = MaterialTheme.colorScheme.onSecondaryContainer,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = idea.description,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
      )

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedButton(
          onClick = { onCopyPrompt(idea.samplePrompt) },
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
          modifier = Modifier.testTag("copy_button_${idea.id}")
        ) {
          Icon(
            imageVector = Icons.Default.ContentCopy,
            contentDescription = "Prompt Kopyala",
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = "Promptu Kopyala", style = MaterialTheme.typography.labelMedium)
        }
      }
    }
  }
}

private fun copyToClipboard(context: Context, text: String) {
  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
  val clip = ClipData.newPlainText("App Prompt", text)
  clipboard?.setPrimaryClip(clip)
}
