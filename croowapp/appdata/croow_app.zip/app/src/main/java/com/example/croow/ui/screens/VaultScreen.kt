package com.example.croow.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.croow.data.CroowRepository
import com.example.croow.model.VaultItem
import com.example.croow.model.VaultSortOrder
import com.example.croow.ui.components.CompareDialog
import com.example.croow.ui.components.CroowHeader
import com.example.ui.theme.CroowAccentBlue
import com.example.ui.theme.CroowBorder
import com.example.ui.theme.CroowError
import com.example.ui.theme.CroowGreen
import com.example.ui.theme.CroowPurple
import com.example.ui.theme.CroowSurface
import com.example.ui.theme.CroowSurfaceVariant
import com.example.ui.theme.CroowTextMain
import com.example.ui.theme.CroowTextMuted
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun VaultScreen(
  repository: CroowRepository,
  onShowSnackbar: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val vaultItems by repository.vaultItems.collectAsState()

  // Batch progress state
  var isBatchProcessing by remember { mutableStateOf(false) }
  var batchProgressText by remember { mutableStateOf("") }
  var batchFraction by remember { mutableFloatStateOf(0f) }

  // Dialogs
  var itemToCompare by remember { mutableStateOf<VaultItem?>(null) }
  var compareBitmap by remember { mutableStateOf<Bitmap?>(null) }
  var itemToDelete by remember { mutableStateOf<VaultItem?>(null) }

  // Search & Filter
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("Tümü") }
  var isGridView by remember { mutableStateOf(false) }
  var sortOrder by remember { mutableStateOf(VaultSortOrder.DATE_DESC) }
  var showSortMenu by remember { mutableStateOf(false) }
  var showSampleMenu by remember { mutableStateOf(false) }

  // Multi-Photo Picker
  val multiPhotoPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 10)
  ) { uris: List<Uri> ->
    if (uris.isNotEmpty()) {
      coroutineScope.launch {
        isBatchProcessing = true
        batchProgressText = "0 / ${uris.size} görsel hazırlanıyor..."
        batchFraction = 0f

        val bitmapsToCompress = mutableListOf<Pair<String, Bitmap>>()
        for ((idx, uri) in uris.withIndex()) {
          val b = loadBitmapFromUri(context, uri)
          if (b != null) {
            val name = "batch_photo_${System.currentTimeMillis() % 10000}_$idx.png"
            bitmapsToCompress.add(Pair(name, b))
          }
        }

        if (bitmapsToCompress.isNotEmpty()) {
          repository.batchCompressAndAddToVault(bitmapsToCompress) { done, total ->
            batchProgressText = "$done / $total .CRW olarak paketlendi..."
            batchFraction = done.toFloat() / total
          }
          onShowSnackbar("✓ ${bitmapsToCompress.size} adet fotoğraf kasaya başarıyla eklendi!")
        } else {
          onShowSnackbar("Seçilen fotoğraflar okunamadı.")
        }
        isBatchProcessing = false
      }
    }
  }

  // Filter & Sort Items
  val filteredItems = vaultItems.filter { item ->
    val matchesSearch = item.name.contains(searchQuery, ignoreCase = true) || item.category.contains(searchQuery, ignoreCase = true)
    val matchesCategory = when (selectedCategory) {
      "Tümü" -> true
      "⭐ Favoriler" -> item.isFavorite
      "🔥 >%95 Tasarruf" -> item.savingsPercent >= 95
      else -> item.category.equals(selectedCategory, ignoreCase = true)
    }
    matchesSearch && matchesCategory
  }.sortedWith { a, b ->
    when (sortOrder) {
      VaultSortOrder.DATE_DESC -> b.timestamp.compareTo(a.timestamp)
      VaultSortOrder.SAVINGS_DESC -> b.savingsPercent.compareTo(a.savingsPercent)
      VaultSortOrder.SIZE_DESC -> b.rawSizeKb.compareTo(a.rawSizeKb)
      VaultSortOrder.NAME_ASC -> a.name.compareTo(b.name)
    }
  }

  // Calculate vault stats
  val totalCrwKb = vaultItems.sumOf { it.crwSizeKb }
  val totalRawKb = vaultItems.sumOf { it.rawSizeKb }
  val totalSavedKb = maxOf(0, totalRawKb - totalCrwKb)
  val storageMbStr = String.format("%.1f MB", totalCrwKb / 1024f)
  val savedMbStr = String.format("%.1f MB", totalSavedKb / 1024f)
  val avgSavings = if (totalRawKb > 0) ((totalSavedKb.toFloat() / totalRawKb) * 100).toInt() else 95

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("vault_screen_lazy_column"),
    contentPadding = PaddingValues(bottom = 96.dp)
  ) {
    // Header
    item {
      CroowHeader(
        storageMb = storageMbStr,
        savedMb = savedMbStr,
        savingsRate = "$avgSavings%"
      )
    }

    // Action & Multi-Upload Card
    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CroowSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp)
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "☁ Croow Image Vault",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = CroowTextMain
              )
              Text(
                text = "Tek veya çoklu görsel seçip %95 sıkıştırın",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = CroowTextMuted
              )
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFF0D2818)
            ) {
              Text(
                "-%$avgSavings EKO",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = CroowGreen,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Batch Progress Bar
          if (isBatchProcessing) {
            Column(modifier = Modifier.fillMaxWidth()) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  batchProgressText,
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace,
                  color = CroowGreen
                )
                Text(
                  "%${(batchFraction * 100).toInt()}",
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace,
                  color = CroowGreen
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              LinearProgressIndicator(
                progress = { batchFraction },
                color = CroowGreen,
                trackColor = CroowSurfaceVariant,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(6.dp)
                  .clip(RoundedCornerShape(3.dp))
              )
            }
          } else {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Button(
                onClick = {
                  multiPhotoPicker.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                  )
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = CroowGreen,
                  contentColor = Color.Black
                ),
                modifier = Modifier
                  .weight(1.3f)
                  .testTag("upload_multi_photo_picker_btn")
              ) {
                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(17.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Çoklu / Tek Foto Seç", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }

              // Sample Dropdown Menu
              Box {
                OutlinedButton(
                  onClick = { showSampleMenu = true },
                  shape = RoundedCornerShape(10.dp),
                  modifier = Modifier.testTag("dropdown_sample_menu_btn")
                ) {
                  Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(15.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Demo Üret", fontSize = 11.sp)
                }

                DropdownMenu(
                  expanded = showSampleMenu,
                  onDismissRequest = { showSampleMenu = false },
                  modifier = Modifier.background(CroowSurface)
                ) {
                  DropdownMenuItem(
                    text = { Text("🌅 Gün Batımı Manzarası", color = CroowTextMain, fontSize = 12.sp) },
                    onClick = {
                      showSampleMenu = false
                      coroutineScope.launch {
                        val b = repository.createNatureSunsetSampleBitmap()
                        repository.compressAndAddToVault("sunset_${System.currentTimeMillis() % 1000}.png", b, "Doğa")
                        onShowSnackbar("✓ Gün batımı manzarası üretildi ve kasaya eklendi!")
                      }
                    }
                  )
                  DropdownMenuItem(
                    text = { Text("⚡ Neon Şehir Cyberpunk", color = CroowTextMain, fontSize = 12.sp) },
                    onClick = {
                      showSampleMenu = false
                      coroutineScope.launch {
                        val b = repository.createCyberSampleBitmap(
                          title = "CYBERPUNK CITY",
                          primaryColor = android.graphics.Color.rgb(0, 230, 118),
                          secondaryColor = android.graphics.Color.rgb(88, 166, 255),
                          bgColor = android.graphics.Color.rgb(8, 12, 18)
                        )
                        repository.compressAndAddToVault("cyber_city_${System.currentTimeMillis() % 1000}.png", b, "Siber")
                        onShowSnackbar("✓ Siber şehir görseli kasaya eklendi!")
                      }
                    }
                  )
                  DropdownMenuItem(
                    text = { Text("💠 Kuantum Geometri", color = CroowTextMain, fontSize = 12.sp) },
                    onClick = {
                      showSampleMenu = false
                      coroutineScope.launch {
                        val b = repository.createGeometricPatternBitmap()
                        repository.compressAndAddToVault("quantum_${System.currentTimeMillis() % 1000}.png", b, "Soyut")
                        onShowSnackbar("✓ Kuantum geometrik örüntü eklendi!")
                      }
                    }
                  )
                }
              }
            }
          }
        }
      }
    }

    // Search & Control Bar
    item {
      Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Kasada ara...", fontSize = 12.sp, color = CroowTextMuted) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CroowTextMuted, modifier = Modifier.size(18.dp)) },
            trailingIcon = {
              if (searchQuery.isNotEmpty()) {
                IconButton(onClick = { searchQuery = "" }) {
                  Icon(Icons.Default.Clear, contentDescription = "Temizle", tint = CroowTextMuted, modifier = Modifier.size(16.dp))
                }
              }
            },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = CroowGreen,
              unfocusedBorderColor = CroowBorder,
              focusedTextColor = CroowTextMain,
              unfocusedTextColor = CroowTextMain
            ),
            shape = RoundedCornerShape(10.dp),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )

          Spacer(modifier = Modifier.width(8.dp))

          // View Mode Switch (Grid / List)
          IconButton(
            onClick = { isGridView = !isGridView },
            modifier = Modifier
              .size(44.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(CroowSurface)
              .border(1.dp, CroowBorder, RoundedCornerShape(10.dp))
          ) {
            Icon(
              imageVector = if (isGridView) Icons.Default.ViewList else Icons.Default.GridView,
              contentDescription = "Görünüm Değiştir",
              tint = CroowGreen,
              modifier = Modifier.size(20.dp)
            )
          }

          Spacer(modifier = Modifier.width(6.dp))

          // Sort Menu
          Box {
            IconButton(
              onClick = { showSortMenu = true },
              modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(CroowSurface)
                .border(1.dp, CroowBorder, RoundedCornerShape(10.dp))
            ) {
              Icon(
                imageVector = Icons.Default.Sort,
                contentDescription = "Sırala",
                tint = CroowAccentBlue,
                modifier = Modifier.size(20.dp)
              )
            }

            DropdownMenu(
              expanded = showSortMenu,
              onDismissRequest = { showSortMenu = false },
              modifier = Modifier.background(CroowSurface)
            ) {
              DropdownMenuItem(
                text = { Text("Tarihe Göre (En Yeni)", color = CroowTextMain, fontSize = 12.sp) },
                onClick = { sortOrder = VaultSortOrder.DATE_DESC; showSortMenu = false }
              )
              DropdownMenuItem(
                text = { Text("Tasarrufa Göre (En Çok)", color = CroowTextMain, fontSize = 12.sp) },
                onClick = { sortOrder = VaultSortOrder.SAVINGS_DESC; showSortMenu = false }
              )
              DropdownMenuItem(
                text = { Text("Boyuta Göre (En Büyük)", color = CroowTextMain, fontSize = 12.sp) },
                onClick = { sortOrder = VaultSortOrder.SIZE_DESC; showSortMenu = false }
              )
              DropdownMenuItem(
                text = { Text("İsme Göre (A-Z)", color = CroowTextMain, fontSize = 12.sp) },
                onClick = { sortOrder = VaultSortOrder.NAME_ASC; showSortMenu = false }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Categories Chips
        val categories = listOf("Tümü", "⭐ Favoriler", "🔥 >%95 Tasarruf", "Siber", "Doğa", "Soyut", "Galeri")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(categories) { cat ->
            FilterChip(
              selected = (selectedCategory == cat),
              onClick = { selectedCategory = cat },
              label = { Text(cat, fontSize = 11.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = CroowGreen.copy(alpha = 0.2f),
                selectedLabelColor = CroowGreen,
                containerColor = CroowSurface,
                labelColor = CroowTextMuted
              ),
              border = FilterChipDefaults.filterChipBorder(
                borderColor = if (selectedCategory == cat) CroowGreen else CroowBorder,
                enabled = true,
                selected = (selectedCategory == cat)
              )
            )
          }
        }
      }
    }

    // Vault Gallery Count
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "GÖSTERİLEN DOSYALAR (${filteredItems.size}/${vaultItems.size})",
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp,
          color = CroowTextMuted
        )
      }
    }

    // Empty state
    if (filteredItems.isEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🔍", fontSize = 32.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Filtreye uygun görsel bulunamadı.", fontSize = 13.sp, color = CroowTextMuted)
          }
        }
      }
    } else {
      // Items rendering (List or Grid)
      if (!isGridView) {
        items(filteredItems, key = { it.id }) { item ->
          VaultDetailedCard(
            item = item,
            onInspect = {
              coroutineScope.launch {
                compareBitmap = repository.decompressItem(item)
                itemToCompare = item
              }
            },
            onToggleFavorite = { repository.toggleFavorite(item.id) },
            onExportJpeg = {
              coroutineScope.launch {
                val f = repository.exportItemAsJpeg(item)
                if (f != null) {
                  shareFile(context, f, "image/jpeg", "${item.name}.jpg Paylaş")
                  onShowSnackbar("✓ JPG olarak dışa aktarıldı!")
                }
              }
            },
            onShareCrw = { shareCrwFile(context, item) },
            onDelete = { itemToDelete = item },
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
          )
        }
      } else {
        // 2-Column Grid representation using paired items
        val chunkedItems = filteredItems.chunked(2)
        items(chunkedItems) { pair ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            pair.forEach { item ->
              VaultGridCard(
                item = item,
                onInspect = {
                  coroutineScope.launch {
                    compareBitmap = repository.decompressItem(item)
                    itemToCompare = item
                  }
                },
                onToggleFavorite = { repository.toggleFavorite(item.id) },
                modifier = Modifier.weight(1f)
              )
            }
            if (pair.size == 1) {
              Spacer(modifier = Modifier.weight(1f))
            }
          }
        }
      }
    }

    // Compare Dialog with interactive split slider
    item {
      itemToCompare?.let { item ->
        CompareDialog(
          item = item,
          bitmap = compareBitmap,
          originalBitmap = item.originalBitmap,
          onToggleFavorite = { repository.toggleFavorite(it) },
          onExportJpeg = {
            coroutineScope.launch {
              val f = repository.exportItemAsJpeg(item)
              if (f != null) {
                shareFile(context, f, "image/jpeg", "${item.name}.jpg Paylaş")
                onShowSnackbar("✓ JPG olarak dışa aktarıldı!")
              }
            }
          },
          onDismiss = { itemToCompare = null }
        )
      }
    }

    // Delete dialog
    item {
      itemToDelete?.let { item ->
        AlertDialog(
          onDismissRequest = { itemToDelete = null },
          title = { Text("Kasadan Silinsin mi?", color = CroowTextMain) },
          text = {
            Text(
              "${item.name} adlı .CRW dosyası Croow kasasından kalıcı olarak silinecektir.",
              color = CroowTextMuted
            )
          },
          confirmButton = {
            Button(
              onClick = {
                repository.deleteVaultItem(item.id)
                itemToDelete = null
                onShowSnackbar("Dosya kasadan silindi.")
              },
              colors = ButtonDefaults.buttonColors(containerColor = CroowError)
            ) {
              Text("Sil", color = Color.White)
            }
          },
          dismissButton = {
            TextButton(onClick = { itemToDelete = null }) {
              Text("İptal", color = CroowTextMuted)
            }
          },
          containerColor = CroowSurface
        )
      }
    }
  }
}

@Composable
fun VaultDetailedCard(
  item: VaultItem,
  onInspect: () -> Unit,
  onToggleFavorite: () -> Unit,
  onExportJpeg: () -> Unit,
  onShareCrw: () -> Unit,
  onDelete: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = CroowSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
    modifier = modifier
      .fillMaxWidth()
      .testTag("vault_item_${item.id}")
  ) {
    Column {
      // Thumbnail
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(170.dp)
          .background(Color.Black)
          .clickable { onInspect() },
        contentAlignment = Alignment.Center
      ) {
        if (item.thumbnail != null) {
          Image(
            bitmap = item.thumbnail.asImageBitmap(),
            contentDescription = item.name,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
          )
        } else {
          Text(".CRW Önizleme", fontFamily = FontFamily.Monospace, color = CroowTextMuted)
        }

        // Favorite Button on Image
        IconButton(
          onClick = onToggleFavorite,
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(6.dp)
            .size(34.dp)
            .clip(CircleShape)
            .background(Color(0xAA06080D))
        ) {
          Icon(
            imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Favori",
            tint = if (item.isFavorite) Color(0xFFFF5F56) else Color.White,
            modifier = Modifier.size(18.dp)
          )
        }

        // Overlay Category Badge
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = Color(0xDD06080D),
          border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
          modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(8.dp)
        ) {
          Text(
            text = "${item.category} • CRW4 Spatial",
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = CroowAccentBlue,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
      }

      // Metadata & Action Rows
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = item.name,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = CroowTextMain,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )

          Surface(
            shape = RoundedCornerShape(4.dp),
            color = Color(0xFF0D2818)
          ) {
            Text(
              text = "-%${item.savingsPercent}",
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              color = CroowGreen,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "Raw: ${item.rawSizeKb} KB → ${item.crwSizeKb} KB",
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            color = CroowTextMuted
          )
          Text(
            text = "${item.origWidth}x${item.origHeight}",
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            color = CroowTextMuted
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          OutlinedButton(
            onClick = onInspect,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("İncele", fontSize = 11.sp)
          }

          OutlinedButton(
            onClick = onExportJpeg,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            modifier = Modifier.weight(1.1f)
          ) {
            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("JPG Olarak Al", fontSize = 11.sp)
          }

          OutlinedButton(
            onClick = onShareCrw,
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(".CRW", fontSize = 11.sp)
          }

          IconButton(
            onClick = onDelete,
            modifier = Modifier.size(34.dp)
          ) {
            Icon(Icons.Default.Delete, contentDescription = "Sil", tint = CroowError.copy(alpha = 0.8f))
          }
        }
      }
    }
  }
}

@Composable
fun VaultGridCard(
  item: VaultItem,
  onInspect: () -> Unit,
  onToggleFavorite: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(10.dp),
    colors = CardDefaults.cardColors(containerColor = CroowSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
    modifier = modifier.clickable { onInspect() }
  ) {
    Column {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .aspectRatio(1f)
          .background(Color.Black),
        contentAlignment = Alignment.Center
      ) {
        if (item.thumbnail != null) {
          Image(
            bitmap = item.thumbnail.asImageBitmap(),
            contentDescription = item.name,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
          )
        }

        // Top Favorite
        IconButton(
          onClick = onToggleFavorite,
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(4.dp)
            .size(28.dp)
            .clip(CircleShape)
            .background(Color(0x9906080D))
        ) {
          Icon(
            imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Favori",
            tint = if (item.isFavorite) Color(0xFFFF5F56) else Color.White,
            modifier = Modifier.size(15.dp)
          )
        }

        // Bottom savings
        Surface(
          shape = RoundedCornerShape(4.dp),
          color = Color(0xDD06080D),
          modifier = Modifier
            .align(Alignment.BottomStart)
            .padding(4.dp)
        ) {
          Text(
            text = "-%${item.savingsPercent}",
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = CroowGreen,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
          )
        }
      }

      Column(modifier = Modifier.padding(8.dp)) {
        Text(
          text = item.name,
          fontWeight = FontWeight.SemiBold,
          fontSize = 11.sp,
          color = CroowTextMain,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = "${item.crwSizeKb} KB",
          fontSize = 10.sp,
          fontFamily = FontFamily.Monospace,
          color = CroowTextMuted
        )
      }
    }
  }
}

private suspend fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
  try {
    context.contentResolver.openInputStream(uri)?.use { stream ->
      BitmapFactory.decodeStream(stream)
    }
  } catch (e: Exception) {
    e.printStackTrace()
    null
  }
}

private fun shareCrwFile(context: Context, item: VaultItem) {
  try {
    val file = File(item.localCrwPath)
    if (file.exists()) {
      shareFile(context, file, "application/octet-stream", "${item.name}.crw Paylaş")
    }
  } catch (e: Exception) {
    e.printStackTrace()
  }
}

private fun shareFile(context: Context, file: File, mimeType: String, title: String) {
  try {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
      type = mimeType
      putExtra(Intent.EXTRA_STREAM, uri)
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, title))
  } catch (e: Exception) {
    e.printStackTrace()
  }
}
