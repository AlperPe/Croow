package com.example.croow.ui.components

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import com.example.croow.model.VaultItem
import com.example.ui.theme.CroowAccentBlue
import com.example.ui.theme.CroowBorder
import com.example.ui.theme.CroowGreen
import com.example.ui.theme.CroowSurface
import com.example.ui.theme.CroowSurfaceVariant
import com.example.ui.theme.CroowTextMain
import com.example.ui.theme.CroowTextMuted
import java.io.File

@Composable
fun CompareDialog(
  item: VaultItem,
  bitmap: Bitmap?,
  originalBitmap: Bitmap? = item.originalBitmap,
  onToggleFavorite: (String) -> Unit = {},
  onExportJpeg: (VaultItem) -> Unit = {},
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  var viewMode by remember { mutableIntStateOf(0) } // 0: Split Slider, 1: CRW Only, 2: Raw Only
  var splitRatio by remember { mutableFloatStateOf(0.5f) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(18.dp),
      color = CroowSurface,
      border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
      modifier = Modifier
        .fillMaxWidth()
        .padding(4.dp)
        .testTag("compare_dialog")
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = item.name,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = CroowTextMain
            )
            Text(
              text = "${item.origWidth}x${item.origHeight} • CRW4 Spatial Codec",
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              color = CroowTextMuted
            )
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onToggleFavorite(item.id) }) {
              Icon(
                imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "Favori",
                tint = if (item.isFavorite) Color(0xFFFF5F56) else CroowTextMuted
              )
            }
            IconButton(onClick = onDismiss) {
              Icon(Icons.Default.Close, contentDescription = "Kapat", tint = CroowTextMuted)
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Mode Selector Chips
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          FilterChip(
            selected = (viewMode == 0),
            onClick = { viewMode = 0 },
            label = { Text("Kaydırmalı (Split)", fontSize = 11.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = CroowGreen.copy(alpha = 0.2f),
              selectedLabelColor = CroowGreen
            )
          )
          FilterChip(
            selected = (viewMode == 1),
            onClick = { viewMode = 1 },
            label = { Text(".CRW (%95)", fontSize = 11.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = CroowAccentBlue.copy(alpha = 0.2f),
              selectedLabelColor = CroowAccentBlue
            )
          )
          FilterChip(
            selected = (viewMode == 2),
            onClick = { viewMode = 2 },
            label = { Text("Orijinal Raw", fontSize = 11.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = Color(0x33FFFFFF),
              selectedLabelColor = CroowTextMain
            )
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Image Interactive Canvas
        BoxWithConstraints(
          modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.Black)
            .border(1.dp, CroowBorder, RoundedCornerShape(12.dp))
        ) {
          val boxWidth = maxWidth
          val boxHeight = maxHeight

          val crwBmp = bitmap ?: item.thumbnail
          val rawBmp = originalBitmap ?: crwBmp

          if (crwBmp != null) {
            when (viewMode) {
              0 -> {
                // Interactive Split View
                Box(modifier = Modifier.fillMaxSize()) {
                  // Underneath: Reconstructed CRW Image
                  Image(
                    bitmap = crwBmp.asImageBitmap(),
                    contentDescription = "CRW Reconstructed",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                  )

                  // On top: Raw Image clipped to split ratio
                  if (rawBmp != null) {
                    Image(
                      bitmap = rawBmp.asImageBitmap(),
                      contentDescription = "Raw Original",
                      modifier = Modifier
                        .fillMaxSize()
                        .drawWithContent {
                          val clipWidth = size.width * splitRatio
                          clipRect(left = 0f, top = 0f, right = clipWidth, bottom = size.height) {
                            this@drawWithContent.drawContent()
                          }
                        },
                      contentScale = ContentScale.Fit
                    )
                  }

                  // Vertical Split Divider Line
                  Box(
                    modifier = Modifier
                      .offset(x = boxWidth * splitRatio - 1.5.dp)
                      .fillMaxHeight()
                      .width(3.dp)
                      .background(CroowGreen)
                  )

                  // Drag Handle Circle
                  Box(
                    modifier = Modifier
                      .offset(x = boxWidth * splitRatio - 14.dp, y = boxHeight / 2 - 14.dp)
                      .size(28.dp)
                      .clip(CircleShape)
                      .background(CroowGreen)
                      .border(2.dp, Color.Black, CircleShape),
                    contentAlignment = Alignment.Center
                  ) {
                    Text("⬌", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                  }

                  // Touch area for dragging
                  Box(
                    modifier = Modifier
                      .fillMaxSize()
                      .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                          change.consume()
                          val newRatio = (splitRatio + dragAmount.x / size.width).coerceIn(0.05f, 0.95f)
                          splitRatio = newRatio
                        }
                      }
                  )

                  // Labels
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xCC06080D),
                    modifier = Modifier
                      .align(Alignment.TopStart)
                      .padding(8.dp)
                  ) {
                    Text(
                      text = "RAW ORİJİNAL",
                      fontSize = 9.sp,
                      fontFamily = FontFamily.Monospace,
                      fontWeight = FontWeight.Bold,
                      color = Color.White,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }

                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xCC06080D),
                    modifier = Modifier
                      .align(Alignment.TopEnd)
                      .padding(8.dp)
                  ) {
                    Text(
                      text = ".CRW (%${item.savingsPercent} Tasarruf)",
                      fontSize = 9.sp,
                      fontFamily = FontFamily.Monospace,
                      fontWeight = FontWeight.Bold,
                      color = CroowGreen,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }
                }
              }
              1 -> {
                // CRW Only
                Image(
                  bitmap = crwBmp.asImageBitmap(),
                  contentDescription = "CRW Preview",
                  modifier = Modifier.fillMaxSize(),
                  contentScale = ContentScale.Fit
                )
              }
              2 -> {
                // Raw Only
                if (rawBmp != null) {
                  Image(
                    bitmap = rawBmp.asImageBitmap(),
                    contentDescription = "Raw Preview",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Split Slider Control
        if (viewMode == 0) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Raw", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = CroowTextMuted)
            Slider(
              value = splitRatio,
              onValueChange = { splitRatio = it },
              modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
            )
            Text(".CRW", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = CroowGreen)
          }
        }

        // Stats card
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = CroowSurfaceVariant,
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("Orijinal Boyut:", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = CroowTextMuted)
              Text("${item.rawSizeKb} KB", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = CroowTextMain)
            }
            Spacer(modifier = Modifier.height(3.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("CRW4 Spatial Dosya:", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = CroowTextMuted)
              Text("${item.crwSizeKb} KB", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = CroowGreen)
            }
            Spacer(modifier = Modifier.height(3.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text("Görsel Netlik / Tasarruf:", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = CroowTextMuted)
              Text("%${item.fidelityPercent} Netlik / -%${item.savingsPercent}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = CroowAccentBlue)
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Actions
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = { onExportJpeg(item) },
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("JPG Olarak Çıkar", fontSize = 11.sp)
          }

          Button(
            onClick = onDismiss,
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CroowGreen, contentColor = Color.Black),
            modifier = Modifier.weight(1f)
          ) {
            Text("Kapat", fontWeight = FontWeight.Bold, fontSize = 12.sp)
          }
        }
      }
    }
  }
}
