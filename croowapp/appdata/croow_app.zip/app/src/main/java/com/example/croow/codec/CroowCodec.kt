package com.example.croow.codec

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class PaletteColor(val r: Int, val g: Int, val b: Int)

data class CompressionResult(
  val crwBytes: ByteArray,
  val origWidth: Int,
  val origHeight: Int,
  val baseWidth: Int,
  val baseHeight: Int,
  val rawBytesCount: Int,
  val crwBytesCount: Int,
  val savingsPercent: Int,
  val fidelityPercent: Float,
  val elapsedMs: Long,
  val decodedPreview: Bitmap
)

data class DecompressionResult(
  val bitmap: Bitmap,
  val origWidth: Int,
  val origHeight: Int,
  val baseWidth: Int,
  val baseHeight: Int,
  val paletteSize: Int,
  val basePayloadSize: Int,
  val deltaPayloadSize: Int,
  val elapsedMs: Long
)

object CroowCodec {

  // Universal 255-Root Brain Palette generated systematically or learned
  val universalRoots: List<PaletteColor> = generateUniversalPalette()

  private fun generateUniversalPalette(): List<PaletteColor> {
    val palette = mutableListOf<PaletteColor>()
    // Standard color cube distribution across 255 levels
    for (r in 0..5) {
      for (g in 0..5) {
        for (b in 0..5) {
          if (palette.size < 216) {
            palette.add(PaletteColor(r * 51, g * 51, b * 51))
          }
        }
      }
    }
    // Grayscale ramp and key cyber accents (neon green, electric cyan, vibrant purple)
    for (i in 0..15) {
      val v = i * 17
      if (palette.size < 240) palette.add(PaletteColor(v, v, v))
    }
    // Key Croow branding colors
    palette.add(PaletteColor(0, 230, 118))   // Neon Green
    palette.add(PaletteColor(88, 166, 255))  // Cyber Blue
    palette.add(PaletteColor(124, 58, 237))  // Croow Violet
    palette.add(PaletteColor(255, 123, 114)) // Error Rose
    palette.add(PaletteColor(245, 158, 11))  // Amber Warning
    while (palette.size < 255) {
      val idx = palette.size
      palette.add(PaletteColor((idx * 37) % 256, (idx * 59) % 256, (idx * 83) % 256))
    }
    return palette
  }

  /**
   * Compresses an Android Bitmap into .CRW binary format
   */
  fun compress(
    srcBitmap: Bitmap,
    targetBaseWidth: Int = 160,
    lumThreshold: Int = 22,
    palette: List<PaletteColor> = universalRoots
  ): CompressionResult {
    val startTime = System.currentTimeMillis()
    val origW = srcBitmap.width
    val origH = srcBitmap.height

    val baseW = min(origW, targetBaseWidth)
    val baseH = max(1, (origH * (baseW.toFloat() / origW)).roundToInt())

    // 1. Resize to base thumbnail
    val baseBitmap = Bitmap.createScaledBitmap(srcBitmap, baseW, baseH, true)
    val basePixels = IntArray(baseW * baseH)
    baseBitmap.getPixels(basePixels, 0, baseW, 0, 0, baseW, baseH)

    // 2. Map base pixels to palette indices
    val palSize = min(palette.size, 255)
    val baseIndices = IntArray(basePixels.size)
    for (i in basePixels.indices) {
      val pixel = basePixels[i]
      val pr = (pixel shr 16) and 0xFF
      val pg = (pixel shr 8) and 0xFF
      val pb = pixel and 0xFF

      var minDist = Int.MAX_VALUE
      var bestIdx = 0
      for (idx in 0 until palSize) {
        val c = palette[idx]
        val dr = pr - c.r
        val dg = pg - c.g
        val db = pb - c.b
        val d = dr * dr + dg * dg + db * db
        if (d < minDist) {
          minDist = d
          bestIdx = idx
          if (d == 0) break
        }
      }
      baseIndices[i] = bestIdx
    }

    // 3. RLE encode base indices
    val basePayloadStream = ByteArrayOutputStream()
    var bi = 0
    val totalBase = baseIndices.size
    while (bi < totalBase) {
      val value = baseIndices[bi]
      var run = 1
      while (bi + run < totalBase && baseIndices[bi + run] == value && run < 127) {
        run++
      }
      if (run > 1) {
        basePayloadStream.write(0x80 or run)
        basePayloadStream.write(value)
        bi += run
      } else {
        basePayloadStream.write(value)
        bi++
      }
    }
    val basePayload = basePayloadStream.toByteArray()

    // 4. Reconstruct base image and upscale to orig size for delta analysis
    val expBaseBitmap = Bitmap.createBitmap(baseW, baseH, Bitmap.Config.ARGB_8888)
    val expPixels = IntArray(baseW * baseH)
    for (i in baseIndices.indices) {
      val c = palette[baseIndices[i]]
      expPixels[i] = AndroidColor.rgb(c.r, c.g, c.b)
    }
    expBaseBitmap.setPixels(expPixels, 0, baseW, 0, 0, baseW, baseH)

    val upscaledBitmap = Bitmap.createScaledBitmap(expBaseBitmap, origW, origH, true)
    val upscaledPixels = IntArray(origW * origH)
    upscaledBitmap.getPixels(upscaledPixels, 0, origW, 0, 0, origW, origH)

    val origPixels = IntArray(origW * origH)
    srcBitmap.getPixels(origPixels, 0, origW, 0, 0, origW, origH)

    // 5. Delta payload (Luminance residual)
    val deltaStream = ByteArrayOutputStream()
    var zeroRuns = 0
    var diffSum = 0L

    for (i in 0 until origW * origH) {
      val op = origPixels[i]
      val or = (op shr 16) and 0xFF
      val og = (op shr 8) and 0xFF
      val ob = op and 0xFF

      val up = upscaledPixels[i]
      val ur = (up shr 16) and 0xFF
      val ug = (up shr 8) and 0xFF
      val ub = up and 0xFF

      val dr = or - ur
      val dg = og - ug
      val db = ob - ub

      diffSum += (abs(dr) + abs(dg) + abs(db)) / 3

      val lum = abs(0.299f * dr + 0.587f * dg + 0.114f * db)
      if (lum < lumThreshold) {
        zeroRuns++
        if (zeroRuns == 255) {
          deltaStream.write(0x00)
          deltaStream.write(255)
          zeroRuns = 0
        }
      } else {
        if (zeroRuns > 0) {
          deltaStream.write(0x00)
          deltaStream.write(zeroRuns)
          zeroRuns = 0
        }
        deltaStream.write(0x01)
        deltaStream.write(max(-128, min(127, dr)))
        deltaStream.write(max(-128, min(127, dg)))
        deltaStream.write(max(-128, min(127, db)))
      }
    }
    if (zeroRuns > 0) {
      deltaStream.write(0x00)
      deltaStream.write(zeroRuns)
    }
    val deltaPayload = deltaStream.toByteArray()

    // 6. Write final CRW4 binary structure
    val crwStream = ByteArrayOutputStream()
    val dos = DataOutputStream(crwStream)
    dos.writeBytes("CRW4")
    dos.writeShort(origW)
    dos.writeShort(origH)
    dos.writeShort(baseW)
    dos.writeShort(baseH)
    dos.writeByte(palSize)
    for (i in 0 until palSize) {
      val c = palette[i]
      dos.writeByte(c.r)
      dos.writeByte(c.g)
      dos.writeByte(c.b)
    }
    dos.writeInt(basePayload.size)
    dos.write(basePayload)
    dos.writeInt(deltaPayload.size)
    dos.write(deltaPayload)
    dos.flush()

    val crwBytes = crwStream.toByteArray()
    val rawBytesCount = origW * origH * 3
    val crwBytesCount = crwBytes.size
    val savingsPercent = if (rawBytesCount > 0) {
      max(0, (((rawBytesCount - crwBytesCount).toFloat() / rawBytesCount) * 100).roundToInt())
    } else 0

    val avgDiff = (diffSum.toDouble() / (origW * origH)).toFloat()
    val fidelityPercent = max(0f, min(100f, 100f - (avgDiff / 2.55f)))
    val elapsedMs = System.currentTimeMillis() - startTime

    // Build reconstructed bitmap for instant review
    val decoded = decompress(crwBytes).bitmap

    return CompressionResult(
      crwBytes = crwBytes,
      origWidth = origW,
      origHeight = origH,
      baseWidth = baseW,
      baseHeight = baseH,
      rawBytesCount = rawBytesCount,
      crwBytesCount = crwBytesCount,
      savingsPercent = savingsPercent,
      fidelityPercent = (fidelityPercent * 10f).roundToInt() / 10f,
      elapsedMs = elapsedMs,
      decodedPreview = decoded
    )
  }

  /**
   * Decompresses .CRW binary bytes back into a full-resolution Android Bitmap
   */
  fun decompress(crwBytes: ByteArray): DecompressionResult {
    val startTime = System.currentTimeMillis()
    val dis = DataInputStream(ByteArrayInputStream(crwBytes))

    val magicBytes = ByteArray(4)
    dis.readFully(magicBytes)
    val magic = String(magicBytes)
    require(magic == "CRW4" || magic == "CRW5") { "Invalid CRW magic header: $magic" }

    val origW = dis.readUnsignedShort()
    val origH = dis.readUnsignedShort()
    val baseW = dis.readUnsignedShort()
    val baseH = dis.readUnsignedShort()

    val palLen = dis.readUnsignedByte()
    val palette = mutableListOf<PaletteColor>()
    for (i in 0 until palLen) {
      val r = dis.readUnsignedByte()
      val g = dis.readUnsignedByte()
      val b = dis.readUnsignedByte()
      palette.add(PaletteColor(r, g, b))
    }

    val baseLen = dis.readInt()
    val basePayload = ByteArray(baseLen)
    dis.readFully(basePayload)

    val deltaLen = dis.readInt()
    val deltaPayload = ByteArray(deltaLen)
    dis.readFully(deltaPayload)

    // 1. Reconstruct base indices
    val totalBase = baseW * baseH
    val baseIndices = IntArray(totalBase)
    var bi = 0
    var pi = 0
    while (bi < basePayload.size && pi < totalBase) {
      val b = basePayload[bi++].toInt() and 0xFF
      if ((b and 0x80) != 0) {
        val run = b and 0x7F
        val value = basePayload[bi++].toInt() and 0xFF
        for (r in 0 until run) {
          if (pi < totalBase) baseIndices[pi++] = value
        }
      } else {
        baseIndices[pi++] = b
      }
    }

    // 2. Render base bitmap
    val baseBitmap = Bitmap.createBitmap(baseW, baseH, Bitmap.Config.ARGB_8888)
    val basePixels = IntArray(totalBase)
    for (i in 0 until totalBase) {
      val idx = baseIndices[i]
      val c = if (idx < palette.size) palette[idx] else PaletteColor(0, 0, 0)
      basePixels[i] = AndroidColor.rgb(c.r, c.g, c.b)
    }
    baseBitmap.setPixels(basePixels, 0, baseW, 0, 0, baseW, baseH)

    // 3. Upscale to original resolution
    val reconstructed = Bitmap.createScaledBitmap(baseBitmap, origW, origH, true).copy(Bitmap.Config.ARGB_8888, true)
    val finalPixels = IntArray(origW * origH)
    reconstructed.getPixels(finalPixels, 0, origW, 0, 0, origW, origH)

    // 4. Apply delta adjustments
    var di = 0
    var pixIdx = 0
    val totalPixels = origW * origH
    while (di < deltaPayload.size && pixIdx < totalPixels) {
      val tag = deltaPayload[di++].toInt() and 0xFF
      if (tag == 0x00) {
        if (di < deltaPayload.size) {
          val run = deltaPayload[di++].toInt() and 0xFF
          pixIdx += run
        }
      } else if (tag == 0x01) {
        if (di + 2 < deltaPayload.size && pixIdx < totalPixels) {
          val dr = deltaPayload[di++].toInt()
          val dg = deltaPayload[di++].toInt()
          val db = deltaPayload[di++].toInt()

          val cp = finalPixels[pixIdx]
          val cr = (cp shr 16) and 0xFF
          val cg = (cp shr 8) and 0xFF
          val cb = cp and 0xFF

          val nr = min(255, max(0, cr + dr))
          val ng = min(255, max(0, cg + dg))
          val nb = min(255, max(0, cb + db))

          finalPixels[pixIdx] = AndroidColor.rgb(nr, ng, nb)
          pixIdx++
        }
      }
    }
    reconstructed.setPixels(finalPixels, 0, origW, 0, 0, origW, origH)
    val elapsedMs = System.currentTimeMillis() - startTime

    return DecompressionResult(
      bitmap = reconstructed,
      origWidth = origW,
      origHeight = origH,
      baseWidth = baseW,
      baseHeight = baseH,
      paletteSize = palLen,
      basePayloadSize = baseLen,
      deltaPayloadSize = deltaLen,
      elapsedMs = elapsedMs
    )
  }
}
