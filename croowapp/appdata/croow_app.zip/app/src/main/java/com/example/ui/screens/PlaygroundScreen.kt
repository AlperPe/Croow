package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.model.DemoTask

@Composable
fun PlaygroundScreen(
  onShowSnackbar: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  // Counter state
  var counter by remember { mutableIntStateOf(5) }

  // Slider state
  var sliderValue by remember { mutableFloatStateOf(70f) }

  // Switch state
  var notificationsEnabled by remember { mutableStateOf(true) }

  // Tasks state
  var newTaskText by remember { mutableStateOf("") }
  var nextTaskId by remember { mutableIntStateOf(4) }
  val tasks = remember {
    mutableStateListOf(
      DemoTask(1, "Sohbete yapmak istediğin uygulamayı yaz", true, "Başlangıç"),
      DemoTask(2, "Emülatörde oluşan uygulamayı test et", false, "Geliştirme"),
      DemoTask(3, "Yeni özellikler ekle ve özelleştir", false, "İpuçları")
    )
  }

  // Accent colors
  val accentColors = listOf(
    Color(0xFF6366F1), // Indigo
    Color(0xFF8B5CF6), // Violet
    Color(0xFF10B981), // Emerald
    Color(0xFFF59E0B), // Amber
    Color(0xFFF43F5E)  // Rose
  )
  var selectedAccentIndex by remember { mutableIntStateOf(0) }
  val activeAccent = accentColors[selectedAccentIndex]

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("playground_lazy_column"),
    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 96.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header
    item {
      Column {
        Text(
          text = "İnteraktif Deneme Alanı",
          style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "Jetpack Compose bileşenlerinin ve durum yönetiminin canlı demosu.",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Dynamic Color Picker Card
    item {
      ElevatedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "🎨 Canlı Vurgu Rengi",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Aşağıdaki renklerden birine dokunarak dinamik renk tepkisini test edin:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(12.dp))
          Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            accentColors.forEachIndexed { index, color ->
              val isSelected = (index == selectedAccentIndex)
              Box(
                modifier = Modifier
                  .size(if (isSelected) 44.dp else 36.dp)
                  .clip(CircleShape)
                  .background(color)
                  .clickable { selectedAccentIndex = index }
                  .testTag("color_circle_$index"),
                contentAlignment = Alignment.Center
              ) {
                if (isSelected) {
                  Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                  )
                }
              }
            }
          }
        }
      }
    }

    // Counter Widget Card
    item {
      ElevatedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "🔢 İnteraktif Sayaç",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
              color = MaterialTheme.colorScheme.onSurface
            )
            IconButton(
              onClick = { counter = 0 },
              modifier = Modifier.testTag("counter_reset_button")
            ) {
              Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = "Sıfırla",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = "$counter",
            style = MaterialTheme.typography.displayMedium.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 54.sp
            ),
            color = activeAccent
          )

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            FilledTonalButton(
              onClick = { counter-- },
              shape = CircleShape,
              modifier = Modifier
                .size(48.dp)
                .testTag("counter_decrement_button"),
              contentPadding = PaddingValues(0.dp)
            ) {
              Icon(Icons.Default.Remove, contentDescription = "Eksilt")
            }

            Button(
              onClick = { counter++ },
              shape = CircleShape,
              colors = ButtonDefaults.buttonColors(containerColor = activeAccent),
              modifier = Modifier
                .size(48.dp)
                .testTag("counter_increment_button"),
              contentPadding = PaddingValues(0.dp)
            ) {
              Icon(Icons.Default.Add, contentDescription = "Arttır")
            }
          }
        }
      }
    }

    // Slider and Switch Card
    item {
      ElevatedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "⚙️ Ayarlar & Giriş Kontrolleri",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface
          )

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "Bildirim İzni",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = if (notificationsEnabled) "Açık" else "Kapalı",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Switch(
              checked = notificationsEnabled,
              onCheckedChange = { notificationsEnabled = it },
              modifier = Modifier.testTag("notification_switch")
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "İlerleme / Seviye",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "%${sliderValue.toInt()}",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = activeAccent
              )
            }
            Slider(
              value = sliderValue,
              onValueChange = { sliderValue = it },
              valueRange = 0f..100f,
              modifier = Modifier.testTag("progress_slider")
            )
          }
        }
      }
    }

    // Mini Task Manager Card
    item {
      ElevatedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "📋 Hızlı Görev Listesi",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Ekleme, işaretleme ve silme durumlarını canlı deneyin:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            OutlinedTextField(
              value = newTaskText,
              onValueChange = { newTaskText = it },
              placeholder = { Text("Yeni görev yaz...", fontSize = 14.sp) },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                .weight(1f)
                .testTag("task_input_field"),
              singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
              onClick = {
                if (newTaskText.isNotBlank()) {
                  tasks.add(DemoTask(nextTaskId++, newTaskText.trim(), false, "Özel"))
                  newTaskText = ""
                  onShowSnackbar("Yeni görev eklendi!")
                }
              },
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = activeAccent),
              modifier = Modifier.testTag("add_task_button")
            ) {
              Icon(Icons.Default.Add, contentDescription = "Ekle")
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Task list
          tasks.forEach { task ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Checkbox(
                checked = task.isCompleted,
                onCheckedChange = { checked ->
                  val index = tasks.indexOfFirst { it.id == task.id }
                  if (index != -1) {
                    tasks[index] = task.copy(isCompleted = checked)
                  }
                },
                modifier = Modifier.testTag("task_checkbox_${task.id}")
              )
              Text(
                text = task.title,
                style = MaterialTheme.typography.bodyMedium.copy(
                  textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                ),
                color = if (task.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                  .weight(1f)
                  .padding(horizontal = 6.dp)
              )
              IconButton(
                onClick = {
                  tasks.removeIf { it.id == task.id }
                  onShowSnackbar("Görev silindi")
                },
                modifier = Modifier.testTag("delete_task_button_${task.id}")
              ) {
                Icon(
                  imageVector = Icons.Default.Delete,
                  contentDescription = "Sil",
                  tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                  modifier = Modifier.size(18.dp)
                )
              }
            }
          }
        }
      }
    }
  }
}
