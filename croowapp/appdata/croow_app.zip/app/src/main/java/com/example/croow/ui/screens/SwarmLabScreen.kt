package com.example.croow.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.croow.codec.CroowCodec
import com.example.croow.codec.PaletteColor
import com.example.croow.data.CroowRepository
import com.example.croow.model.LogType
import com.example.ui.theme.CroowAccentBlue
import com.example.ui.theme.CroowBgDarker
import com.example.ui.theme.CroowBorder
import com.example.ui.theme.CroowGreen
import com.example.ui.theme.CroowPurple
import com.example.ui.theme.CroowSurface
import com.example.ui.theme.CroowSurfaceVariant
import com.example.ui.theme.CroowTextMain
import com.example.ui.theme.CroowTextMuted
import kotlinx.coroutines.launch

@Composable
fun SwarmLabScreen(
  repository: CroowRepository,
  onShowSnackbar: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val coroutineScope = rememberCoroutineScope()
  val stats by repository.swarmStats.collectAsState()
  val logs by repository.swarmLogs.collectAsState()

  var currentProgress by remember { mutableFloatStateOf(0f) }
  var selectedPaletteColor by remember { mutableStateOf<PaletteColor?>(null) }
  var showPaletteMatrix by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("swarm_lab_lazy_column"),
    contentPadding = PaddingValues(bottom = 96.dp)
  ) {
    // Header
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp)
      ) {
        Text(
          text = "AUTONOMOUS LEARNING LAB",
          fontSize = 12.sp,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          letterSpacing = 2.sp,
          color = CroowGreen
        )
        Text(
          text = "CROOW Swarm Engine",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
          color = CroowTextMain
        )
        Text(
          text = "Otonom açma-kapama deneyimi ile evrensel kök renkleri eğitir.",
          fontSize = 12.sp,
          fontFamily = FontFamily.Monospace,
          color = CroowTextMuted
        )
      }
    }

    // Stats Bar Card
    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CroowSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              "Swarm Bellek Durumu",
              fontSize = 13.sp,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              color = CroowTextMain
            )
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = Color(0xFF0D2818)
            ) {
              Text(
                "255 Roots Saturated",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = CroowGreen,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            SwarmStatBox("İşlenen Resim", "${stats.totalTrainedImages} Adet", CroowAccentBlue, Modifier.weight(1f))
            SwarmStatBox("Ort. Netlik", "%${stats.avgFidelity}", CroowGreen, Modifier.weight(1f))
            SwarmStatBox("Tasarruf", "-%${stats.avgSavings}", CroowPurple, Modifier.weight(1f))
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Action Buttons
          if (stats.isRunning) {
            Column(modifier = Modifier.fillMaxWidth()) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  "Swarm Turu Çalışıyor...",
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace,
                  color = CroowGreen
                )
                Text(
                  "%${(currentProgress * 100).toInt()}",
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  color = CroowGreen
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              LinearProgressIndicator(
                progress = { currentProgress },
                color = CroowGreen,
                trackColor = CroowSurfaceVariant,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(6.dp)
                  .clip(RoundedCornerShape(3.dp))
              )
            }
          } else {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              Button(
                onClick = {
                  coroutineScope.launch {
                    currentProgress = 0f
                    repository.runSwarmSimulation(batchSize = 10) { cur, tot ->
                      currentProgress = cur.toFloat() / tot
                    }
                    onShowSnackbar("✓ 10 Resimlik Swarm Deneyim Turu Tamamlandı!")
                  }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CroowGreen, contentColor = Color.Black),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                  .weight(1f)
                  .testTag("btn_run_swarm_10")
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("10 Resimlik Tur", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }

              OutlinedButton(
                onClick = {
                  showPaletteMatrix = !showPaletteMatrix
                },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
              ) {
                Icon(Icons.Default.Psychology, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (showPaletteMatrix) "Kökleri Gizle" else "255 Kökü Gör", fontSize = 11.sp)
              }
            }
          }
        }
      }
    }

    // 255-Root Palette Visualizer (Collapsible)
    if (showPaletteMatrix) {
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = CroowSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              "255 EVRENSEL KÖK MATRİSİ",
              fontSize = 12.sp,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              color = CroowAccentBlue
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              "Hafızadaki 255 renk kökü. Dokunarak renk değerini inceleyin:",
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              color = CroowTextMuted
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Palette Grid
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.Black)
                .padding(6.dp)
            ) {
              LazyVerticalGrid(
                columns = GridCells.Fixed(16),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier.fillMaxSize()
              ) {
                itemsIndexed(CroowCodec.universalRoots) { idx, root ->
                  Box(
                    modifier = Modifier
                      .aspectRatio(1f)
                      .clip(RoundedCornerShape(2.dp))
                      .background(Color(root.r, root.g, root.b))
                      .clickable { selectedPaletteColor = root }
                  )
                }
              }
            }

            selectedPaletteColor?.let { color ->
              Spacer(modifier = Modifier.height(10.dp))
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(CroowSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Box(
                    modifier = Modifier
                      .size(20.dp)
                      .clip(CircleShape)
                      .background(Color(color.r, color.g, color.b))
                      .border(1.dp, Color.White, CircleShape)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    "RGB(${color.r}, ${color.g}, ${color.b})",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = CroowTextMain
                  )
                }
                Text(
                  String.format("#%02X%02X%02X", color.r, color.g, color.b),
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace,
                  color = CroowGreen
                )
              }
            }
          }
        }
      }
    }

    // Live Terminal Console
    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CroowBgDarker),
        border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Terminal, contentDescription = null, tint = CroowGreen, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                "SWARM KONSOL ÇIKTISI",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = CroowGreen
              )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFF5F56)))
              Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFFBD2E)))
              Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF27C93F)))
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Terminal text items
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(240.dp)
              .clip(RoundedCornerShape(8.dp))
              .background(Color(0xFF030407))
              .border(1.dp, Color(0x15FFFFFF), RoundedCornerShape(8.dp))
              .padding(10.dp)
          ) {
            LazyColumn(
              modifier = Modifier.fillMaxSize(),
              reverseLayout = true
            ) {
              items(logs) { log ->
                val textColor = when (log.type) {
                  LogType.SUCCESS -> CroowGreen
                  LogType.HIGHLIGHT -> CroowAccentBlue
                  LogType.WARNING -> Color(0xFFF59E0B)
                  LogType.INFO -> CroowTextMuted
                }
                Text(
                  text = "${log.timestamp} ${log.message}",
                  fontSize = 10.sp,
                  fontFamily = FontFamily.Monospace,
                  lineHeight = 15.sp,
                  color = textColor,
                  modifier = Modifier.padding(vertical = 1.dp)
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun SwarmStatBox(
  label: String,
  value: String,
  color: Color,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = CroowSurfaceVariant,
    modifier = modifier
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(label, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = CroowTextMuted)
      Spacer(modifier = Modifier.height(2.dp))
      Text(value, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = color)
    }
  }
}
