package com.example.croow.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import com.example.croow.data.CroowRepository
import com.example.croow.ui.screens.CloudConnectScreen
import com.example.croow.ui.screens.CodecStudioScreen
import com.example.croow.ui.screens.SwarmLabScreen
import com.example.croow.ui.screens.VaultScreen
import com.example.ui.theme.CroowAccentBlue
import com.example.ui.theme.CroowBg
import com.example.ui.theme.CroowGreen
import com.example.ui.theme.CroowSurface
import com.example.ui.theme.CroowTextMain
import com.example.ui.theme.CroowTextMuted
import kotlinx.coroutines.launch

enum class CroowNavTab(val label: String, val icon: ImageVector, val tag: String) {
  VAULT("Kasa", Icons.Default.Storage, "tab_vault"),
  STUDIO("Studio", Icons.Default.Compress, "tab_studio"),
  SWARM("Swarm Lab", Icons.Default.Psychology, "tab_swarm"),
  CLOUD("Bulut", Icons.Default.Cloud, "tab_cloud")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CroowApp() {
  val context = LocalContext.current
  val repository = remember { CroowRepository(context) }
  var currentTab by remember { mutableStateOf(CroowNavTab.VAULT) }
  val snackbarHostState = remember { SnackbarHostState() }
  val coroutineScope = rememberCoroutineScope()

  BackHandler(enabled = (currentTab != CroowNavTab.VAULT)) {
    currentTab = CroowNavTab.VAULT
  }

  val showSnackbar: (String) -> Unit = { message ->
    coroutineScope.launch {
      snackbarHostState.showSnackbar(message)
    }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = CroowBg,
    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
    bottomBar = {
      NavigationBar(
        containerColor = CroowSurface,
        modifier = Modifier
          .windowInsetsPadding(WindowInsets.navigationBars)
          .testTag("croow_bottom_nav")
      ) {
        CroowNavTab.values().forEach { tab ->
          val isSelected = (currentTab == tab)
          NavigationBarItem(
            selected = isSelected,
            onClick = { currentTab = tab },
            icon = { Icon(tab.icon, contentDescription = tab.label) },
            label = {
              Text(
                text = tab.label,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = Color.Black,
              selectedTextColor = CroowGreen,
              indicatorColor = CroowGreen,
              unselectedIconColor = CroowTextMuted,
              unselectedTextColor = CroowTextMuted
            ),
            modifier = Modifier.testTag(tab.tag)
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      AnimatedContent(
        targetState = currentTab,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "CroowTabContent"
      ) { tab ->
        when (tab) {
          CroowNavTab.VAULT -> VaultScreen(
            repository = repository,
            onShowSnackbar = showSnackbar
          )
          CroowNavTab.STUDIO -> CodecStudioScreen(
            repository = repository,
            onShowSnackbar = showSnackbar
          )
          CroowNavTab.SWARM -> SwarmLabScreen(
            repository = repository,
            onShowSnackbar = showSnackbar
          )
          CroowNavTab.CLOUD -> CloudConnectScreen(
            onShowSnackbar = showSnackbar
          )
        }
      }
    }
  }
}
