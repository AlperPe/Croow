package com.example.croow.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.croow.codec.CroowCodec
import com.example.croow.model.LogType
import com.example.croow.model.SwarmLogEntry
import com.example.croow.model.SwarmStats
import com.example.croow.model.VaultItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToInt

class CroowRepository(private val context: Context) {

  private val vaultDir = File(context.filesDir, "croow_cloud_vault/storage").apply { mkdirs() }
  private val exportDir = File(context.cacheDir, "croow_exports").apply { mkdirs() }

  private val _vaultItems = MutableStateFlow<List<VaultItem>>(emptyList())
  val vaultItems: StateFlow<List<VaultItem>> = _vaultItems.asStateFlow()

  private val _swarmStats = MutableStateFlow(SwarmStats())
  val swarmStats: StateFlow<SwarmStats> = _swarmStats.asStateFlow()

  private val _swarmLogs = MutableStateFlow<List<SwarmLogEntry>>(emptyList())
  val swarmLogs: StateFlow<List<SwarmLogEntry>> = _swarmLogs.asStateFlow()

  init {
    initializeDefaultVault()
    initializeDefaultLogs()
  }

  private fun initializeDefaultLogs() {
    val initialLogs = listOf(
      SwarmLogEntry("00:01", "[HAFIZA] 255 adet evrensel kök renk hafızaya yüklendi.", LogType.INFO),
      SwarmLogEntry("00:02", "[CROOW] Spatial Image Codec v2.0 - Core 255 Roots Saturated.", LogType.SUCCESS),
      SwarmLogEntry("00:03", "[SİSTEM] Çoklu sıkıştırma ve canlı split-slider inceleme hazır.", LogType.INFO),
      SwarmLogEntry("00:04", "[SİSTEM] Bulut Deposu Hazır: 95% disk tasarrufu devrede.", LogType.INFO)
    )
    _swarmLogs.value = initialLogs
  }

  private fun initializeDefaultVault() {
    if (_vaultItems.value.isEmpty()) {
      val defaultItems = mutableListOf<VaultItem>()

      // 1. Neon Crow Core
      val b1 = createCyberSampleBitmap(
        title = "CROOW NEON CORE",
        primaryColor = Color.rgb(0, 230, 118),
        secondaryColor = Color.rgb(88, 166, 255),
        bgColor = Color.rgb(6, 8, 13)
      )
      saveBitmapAsVaultItem("croow_neon_core.png", b1, "Siber", isFavorite = true)?.let { defaultItems.add(it) }

      // 2. Sunset Nature (Doğa Manzarası)
      val b2 = createNatureSunsetSampleBitmap()
      saveBitmapAsVaultItem("sunset_mountain_view.png", b2, "Doğa")?.let { defaultItems.add(it) }

      // 3. Neural Grid (Soyut / Matris)
      val b3 = createCyberSampleBitmap(
        title = "NEURAL MATRIX 255",
        primaryColor = Color.rgb(124, 58, 237),
        secondaryColor = Color.rgb(0, 230, 118),
        bgColor = Color.rgb(12, 16, 23)
      )
      saveBitmapAsVaultItem("neural_matrix_255.png", b3, "Siber")?.let { defaultItems.add(it) }

      // 4. Abstract Geometry
      val b4 = createGeometricPatternBitmap()
      saveBitmapAsVaultItem("quantum_geometry.png", b4, "Soyut")?.let { defaultItems.add(it) }

      _vaultItems.value = defaultItems
    }
  }

  suspend fun compressAndAddToVault(
    name: String,
    bitmap: Bitmap,
    category: String = "Genel"
  ): VaultItem? = withContext(Dispatchers.IO) {
    val result = saveBitmapAsVaultItem(name, bitmap, category)
    if (result != null) {
      val updated = listOf(result) + _vaultItems.value
      _vaultItems.value = updated
    }
    result
  }

  suspend fun batchCompressAndAddToVault(
    items: List<Pair<String, Bitmap>>,
    onProgress: (done: Int, total: Int) -> Unit
  ) = withContext(Dispatchers.IO) {
    val addedItems = mutableListOf<VaultItem>()
    for ((index, pair) in items.withIndex()) {
      val res = saveBitmapAsVaultItem(pair.first, pair.second, "Galeri")
      if (res != null) {
        addedItems.add(res)
      }
      onProgress(index + 1, items.size)
    }
    if (addedItems.isNotEmpty()) {
      _vaultItems.value = addedItems + _vaultItems.value
    }
  }

  fun toggleFavorite(id: String) {
    _vaultItems.value = _vaultItems.value.map { item ->
      if (item.id == id) item.copy(isFavorite = !item.isFavorite) else item
    }
  }

  fun deleteVaultItem(id: String) {
    val current = _vaultItems.value
    val target = current.find { it.id == id }
    if (target != null) {
      val file = File(target.localCrwPath)
      if (file.exists()) file.delete()
      _vaultItems.value = current.filter { it.id != id }
    }
  }

  suspend fun decompressItem(item: VaultItem): Bitmap? = withContext(Dispatchers.IO) {
    try {
      val file = File(item.localCrwPath)
      if (file.exists()) {
        val bytes = file.readBytes()
        CroowCodec.decompress(bytes).bitmap
      } else {
        item.thumbnail
      }
    } catch (e: Exception) {
      e.printStackTrace()
      item.thumbnail
    }
  }

  suspend fun exportItemAsJpeg(item: VaultItem): File? = withContext(Dispatchers.IO) {
    try {
      val bitmap = decompressItem(item) ?: item.thumbnail ?: return@withContext null
      val baseName = item.name.substringBeforeLast(".")
      val exportFile = File(exportDir, "${baseName}_unfolded.jpg")
      FileOutputStream(exportFile).use { out ->
        bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
      }
      exportFile
    } catch (e: Exception) {
      e.printStackTrace()
      null
    }
  }

  private fun saveBitmapAsVaultItem(
    name: String,
    bitmap: Bitmap,
    category: String = "Genel",
    isFavorite: Boolean = false
  ): VaultItem? {
    try {
      val compressRes = CroowCodec.compress(bitmap, targetBaseWidth = 160, lumThreshold = 22)
      val fileId = "crw_${System.currentTimeMillis()}_${(100..999).random()}"
      val crwFileName = "$fileId.crw"
      val crwFile = File(vaultDir, crwFileName)

      FileOutputStream(crwFile).use { it.write(compressRes.crwBytes) }

      val rawKb = max(1, compressRes.rawBytesCount / 1024)
      val crwKb = max(1, compressRes.crwBytesCount / 1024)
      val savings = compressRes.savingsPercent

      val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
      val timestamp = sdf.format(Date())

      return VaultItem(
        id = fileId,
        name = name,
        crwFileName = crwFileName,
        origWidth = compressRes.origWidth,
        origHeight = compressRes.origHeight,
        rawSizeKb = rawKb,
        crwSizeKb = crwKb,
        savingsPercent = savings,
        fidelityPercent = compressRes.fidelityPercent,
        timestamp = timestamp,
        category = category,
        isFavorite = isFavorite,
        thumbnail = compressRes.decodedPreview,
        originalBitmap = bitmap,
        localCrwPath = crwFile.absolutePath
      )
    } catch (e: Exception) {
      e.printStackTrace()
      return null
    }
  }

  suspend fun runSwarmSimulation(
    batchSize: Int = 10,
    onProgress: (current: Int, total: Int) -> Unit
  ) = withContext(Dispatchers.IO) {
    _swarmStats.value = _swarmStats.value.copy(isRunning = true)

    addLog("[CROOW SWARM] Otonom Açma-Kapama Deneyim Turu Başladı", LogType.HIGHLIGHT)
    addLog("🌐 $batchSize adet görsel için spatial compression simülasyonu başlatılıyor...", LogType.INFO)

    val fidelities = mutableListOf<Float>()
    val savings = mutableListOf<Int>()

    for (i in 1..batchSize) {
      delay(350)
      val fid = 93.8f + (Math.random() * 4.4f).toFloat()
      val sav = (94..96).random()
      val newRoots = if (i % 3 == 0) (1..3).random() else 0

      fidelities.add(fid)
      savings.add(sav)

      val rootMsg = if (newRoots > 0) "(+$newRoots Yeni Kök)" else "(Tanıdık Renkler)"
      val log = String.format(
        Locale.US,
        "[%02d/%02d] Açıldı/Kapatıldı: Doğruluk: %%%.1f | Tasarruf: -%%%d %s",
        i, batchSize, fid, sav, rootMsg
      )
      addLog(log, if (newRoots > 0) LogType.SUCCESS else LogType.INFO)
      onProgress(i, batchSize)
    }

    val avgFid = ((fidelities.average() * 10).roundToInt()) / 10f
    val avgSav = savings.average().roundToInt()

    addLog("🏆 EĞİTİM TURU BAŞARIYLA TAMAMLANDI", LogType.HIGHLIGHT)
    addLog("  ● İşlenen Görsel Sayısı: $batchSize Adet", LogType.SUCCESS)
    addLog("  ● Ortalama Görsel Netlik: %$avgFid Doğruluk", LogType.SUCCESS)
    addLog("  ● Ortalama Hacim Tasarrufu: -%$avgSav Tasarruf", LogType.SUCCESS)
    addLog("  ● Mühürlü Evrensel Bellek: 255 Kök Renk", LogType.SUCCESS)

    _swarmStats.value = SwarmStats(
      totalTrainedImages = _swarmStats.value.totalTrainedImages + batchSize,
      avgFidelity = avgFid,
      avgSavings = avgSav,
      saturatedRootsCount = 255,
      isRunning = false
    )
  }

  private fun addLog(message: String, type: LogType) {
    val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    val entry = SwarmLogEntry(sdf.format(Date()), message, type)
    _swarmLogs.value = listOf(entry) + _swarmLogs.value.take(40)
  }

  fun createCyberSampleBitmap(
    title: String,
    primaryColor: Int,
    secondaryColor: Int,
    bgColor: Int
  ): Bitmap {
    val w = 480
    val h = 480
    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    val bgPaint = Paint().apply { color = bgColor }
    canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)

    val gridPaint = Paint().apply {
      color = Color.argb(40, 255, 255, 255)
      strokeWidth = 1.5f
    }
    for (x in 0..w step 40) canvas.drawLine(x.toFloat(), 0f, x.toFloat(), h.toFloat(), gridPaint)
    for (y in 0..h step 40) canvas.drawLine(0f, y.toFloat(), w.toFloat(), y.toFloat(), gridPaint)

    val circlePaint = Paint().apply {
      color = primaryColor
      style = Paint.Style.STROKE
      strokeWidth = 6f
      isAntiAlias = true
    }
    canvas.drawCircle(w / 2f, h / 2f - 20, 110f, circlePaint)

    val innerPaint = Paint().apply {
      color = secondaryColor
      style = Paint.Style.FILL
      isAntiAlias = true
    }
    canvas.drawCircle(w / 2f - 40, h / 2f - 20, 20f, innerPaint)
    canvas.drawCircle(w / 2f + 40, h / 2f - 20, 20f, innerPaint)

    val beakPaint = Paint().apply {
      color = primaryColor
      style = Paint.Style.FILL
      isAntiAlias = true
    }
    val path = Path().apply {
      moveTo(w / 2f - 25, h / 2f)
      lineTo(w / 2f + 25, h / 2f)
      lineTo(w / 2f, h / 2f + 45)
      close()
    }
    canvas.drawPath(path, beakPaint)

    val bannerRect = RectF(40f, h - 85f, w - 40f, h - 35f)
    val bannerPaint = Paint().apply {
      color = Color.argb(180, 20, 26, 36)
      style = Paint.Style.FILL
    }
    canvas.drawRoundRect(bannerRect, 12f, 12f, bannerPaint)

    val borderPaint = Paint().apply {
      color = primaryColor
      style = Paint.Style.STROKE
      strokeWidth = 2f
    }
    canvas.drawRoundRect(bannerRect, 12f, 12f, borderPaint)

    val textPaint = Paint().apply {
      color = Color.WHITE
      textSize = 20f
      isFakeBoldText = true
      isAntiAlias = true
      textAlign = Paint.Align.CENTER
    }
    canvas.drawText(title, w / 2f, h - 52f, textPaint)

    return bitmap
  }

  fun createNatureSunsetSampleBitmap(): Bitmap {
    val w = 480
    val h = 480
    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    // Sunset Sky Gradient
    val skyShader = LinearGradient(
      0f, 0f, 0f, h * 0.7f,
      intArrayOf(Color.rgb(255, 94, 98), Color.rgb(255, 153, 102), Color.rgb(255, 226, 89)),
      null, Shader.TileMode.CLAMP
    )
    val skyPaint = Paint().apply { shader = skyShader }
    canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), skyPaint)

    // Sun
    val sunPaint = Paint().apply {
      color = Color.argb(220, 255, 255, 240)
      isAntiAlias = true
    }
    canvas.drawCircle(w / 2f, h * 0.42f, 65f, sunPaint)

    // Mountain silhouettes
    val mountainPaint1 = Paint().apply {
      color = Color.rgb(75, 45, 80)
      isAntiAlias = true
      style = Paint.Style.FILL
    }
    val path1 = Path().apply {
      moveTo(0f, h.toFloat())
      lineTo(0f, h * 0.55f)
      lineTo(w * 0.35f, h * 0.38f)
      lineTo(w * 0.65f, h * 0.52f)
      lineTo(w.toFloat(), h * 0.42f)
      lineTo(w.toFloat(), h.toFloat())
      close()
    }
    canvas.drawPath(path1, mountainPaint1)

    val mountainPaint2 = Paint().apply {
      color = Color.rgb(35, 20, 45)
      isAntiAlias = true
      style = Paint.Style.FILL
    }
    val path2 = Path().apply {
      moveTo(0f, h.toFloat())
      lineTo(0f, h * 0.68f)
      lineTo(w * 0.22f, h * 0.58f)
      lineTo(w * 0.55f, h * 0.66f)
      lineTo(w * 0.82f, h * 0.54f)
      lineTo(w.toFloat(), h * 0.65f)
      lineTo(w.toFloat(), h.toFloat())
      close()
    }
    canvas.drawPath(path2, mountainPaint2)

    return bitmap
  }

  fun createGeometricPatternBitmap(): Bitmap {
    val w = 480
    val h = 480
    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    val bgPaint = Paint().apply { color = Color.rgb(10, 14, 22) }
    canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bgPaint)

    val hexColors = listOf(
      Color.rgb(0, 230, 118),
      Color.rgb(88, 166, 255),
      Color.rgb(124, 58, 237),
      Color.rgb(245, 158, 11)
    )

    val size = 60f
    for (row in 0..8) {
      for (col in 0..8) {
        val cx = col * size + 30f
        val cy = row * size + 30f
        val c = hexColors[(row + col) % hexColors.size]

        val p = Paint().apply {
          color = c
          style = if ((row + col) % 2 == 0) Paint.Style.FILL else Paint.Style.STROKE
          strokeWidth = 3f
          isAntiAlias = true
        }
        canvas.drawCircle(cx, cy, 18f, p)
      }
    }
    return bitmap
  }
}
