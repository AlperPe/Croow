package com.example.croow.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CroowAccentBlue
import com.example.ui.theme.CroowBorder
import com.example.ui.theme.CroowGreen
import com.example.ui.theme.CroowPurple
import com.example.ui.theme.CroowSurface
import com.example.ui.theme.CroowTextMain
import com.example.ui.theme.CroowTextMuted

@Composable
fun CroowHeader(
  storageMb: String = "1.2 MB",
  savedMb: String = "24.5 MB",
  savingsRate: String = "95%",
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    // Top Version Tag
    Surface(
      shape = RoundedCornerShape(12.dp),
      color = CroowSurface,
      border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
      modifier = Modifier.padding(bottom = 10.dp)
    ) {
      Text(
        text = "⚡ Core v2.0 • 255 Roots",
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.SemiBold,
        color = CroowTextMuted,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
      )
    }

    // Logo Row: C R [Cyber Crow Mask] W
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center
    ) {
      Text(
        text = "C R",
        fontSize = 32.sp,
        fontWeight = FontWeight.ExtraBold,
        letterSpacing = 8.sp,
        color = CroowTextMain
      )

      Spacer(modifier = Modifier.width(8.dp))

      // Cyber Crow Icon with glowing green circular eyes
      Box(
        modifier = Modifier
          .size(54.dp, 40.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFF0F1522))
          .border(1.dp, Color(0x4458A6FF), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
      ) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Left Eye
          Box(
            modifier = Modifier
              .size(13.dp)
              .clip(CircleShape)
              .background(Color(0xFF06080D))
              .border(2.dp, CroowGreen, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Box(
              modifier = Modifier
                .size(4.dp)
                .clip(CircleShape)
                .background(Color.White)
            )
          }

          // Center Beak Line
          Box(
            modifier = Modifier
              .width(2.dp)
              .height(14.dp)
              .background(CroowGreen)
          )

          // Right Eye
          Box(
            modifier = Modifier
              .size(13.dp)
              .clip(CircleShape)
              .background(Color(0xFF06080D))
              .border(2.dp, CroowGreen, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Box(
              modifier = Modifier
                .size(4.dp)
                .clip(CircleShape)
                .background(Color.White)
            )
          }
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      Text(
        text = "W",
        fontSize = 32.sp,
        fontWeight = FontWeight.ExtraBold,
        color = CroowTextMain
      )
    }

    // Subtitle
    Text(
      text = "CLOUD IMAGE VAULT • 255-ROOT BRAIN",
      fontSize = 11.sp,
      fontFamily = FontFamily.Monospace,
      fontWeight = FontWeight.SemiBold,
      letterSpacing = 2.sp,
      color = CroowTextMuted,
      modifier = Modifier.padding(top = 4.dp)
    )

    // Neon Gradient Divider
    Box(
      modifier = Modifier
        .fillMaxWidth(0.9f)
        .padding(vertical = 12.dp)
        .height(1.5.dp)
        .background(
          Brush.horizontalGradient(
            colors = listOf(
              Color.Transparent,
              CroowPurple.copy(alpha = 0.7f),
              CroowGreen.copy(alpha = 0.9f),
              Color.Transparent
            )
          )
        )
    )

    // Stats Bar
    Row(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 6.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      StatBadge(
        label = "Storage",
        value = storageMb,
        highlightColor = CroowTextMain,
        modifier = Modifier.weight(1f)
      )
      StatBadge(
        label = "Economy",
        value = "-$savingsRate",
        highlightColor = CroowGreen,
        modifier = Modifier.weight(1f)
      )
      StatBadge(
        label = "Brain",
        value = "255 Roots",
        highlightColor = CroowAccentBlue,
        modifier = Modifier.weight(1.2f)
      )
    }
  }
}

@Composable
fun StatBadge(
  label: String,
  value: String,
  highlightColor: Color,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = CroowSurface,
    border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
    modifier = modifier
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = label,
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace,
        color = CroowTextMuted
      )
      Text(
        text = value,
        fontSize = 12.sp,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        color = highlightColor
      )
    }
  }
}
