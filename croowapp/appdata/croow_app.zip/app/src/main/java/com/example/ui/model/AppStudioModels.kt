package com.example.ui.model

import androidx.compose.ui.graphics.vector.ImageVector

data class AppIdea(
  val id: String,
  val title: String,
  val category: String,
  val description: String,
  val samplePrompt: String,
  val iconEmoji: String,
  val badge: String? = null
)

data class DemoTask(
  val id: Int,
  val title: String,
  val isCompleted: Boolean = false,
  val tag: String
)

data class PlatformFeature(
  val title: String,
  val description: String,
  val iconEmoji: String,
  val highlights: List<String>
)
