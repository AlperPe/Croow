package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.screens.CapabilitiesScreen
import com.example.ui.screens.GuideScreen
import com.example.ui.screens.PlaygroundScreen
import kotlinx.coroutines.launch

enum class AppNavTab(val label: String, val icon: ImageVector, val tag: String) {
  GUIDE("Rehber", Icons.Default.RocketLaunch, "nav_tab_guide"),
  PLAYGROUND("Deneme", Icons.Default.PlayArrow, "nav_tab_playground"),
  CAPABILITIES("Yetenekler", Icons.Default.Info, "nav_tab_capabilities")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppStudioApp() {
  var currentTab by remember { mutableStateOf(AppNavTab.GUIDE) }
  val snackbarHostState = remember { SnackbarHostState() }
  val coroutineScope = rememberCoroutineScope()

  BackHandler(enabled = (currentTab != AppNavTab.GUIDE)) {
    currentTab = AppNavTab.GUIDE
  }

  val showSnackbar: (String) -> Unit = { message ->
    coroutineScope.launch {
      snackbarHostState.showSnackbar(message)
    }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
    topBar = {
      TopAppBar(
        title = {
          Text(
            text = "App Studio",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleLarge
          )
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.background,
          titleContentColor = MaterialTheme.colorScheme.onBackground
        )
      )
    },
    bottomBar = {
      NavigationBar(
        modifier = Modifier
          .windowInsetsPadding(WindowInsets.navigationBars)
          .testTag("app_navigation_bar"),
        containerColor = MaterialTheme.colorScheme.surface
      ) {
        AppNavTab.values().forEach { tab ->
          NavigationBarItem(
            selected = (currentTab == tab),
            onClick = { currentTab = tab },
            icon = { Icon(tab.icon, contentDescription = tab.label) },
            label = { Text(tab.label) },
            modifier = Modifier.testTag(tab.tag)
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      AnimatedContent(
        targetState = currentTab,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "TabContent"
      ) { targetTab ->
        when (targetTab) {
          AppNavTab.GUIDE -> GuideScreen(
            onShowSnackbar = showSnackbar,
            onNavigateToPlayground = { currentTab = AppNavTab.PLAYGROUND }
          )
          AppNavTab.PLAYGROUND -> PlaygroundScreen(
            onShowSnackbar = showSnackbar
          )
          AppNavTab.CAPABILITIES -> CapabilitiesScreen()
        }
      }
    }
  }
}
