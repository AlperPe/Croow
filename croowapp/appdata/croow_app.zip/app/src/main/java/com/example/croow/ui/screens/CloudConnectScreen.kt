package com.example.croow.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CroowAccentBlue
import com.example.ui.theme.CroowBorder
import com.example.ui.theme.CroowGreen
import com.example.ui.theme.CroowPurple
import com.example.ui.theme.CroowSurface
import com.example.ui.theme.CroowSurfaceVariant
import com.example.ui.theme.CroowTextMain
import com.example.ui.theme.CroowTextMuted
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun CloudConnectScreen(
  onShowSnackbar: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  var serverUrl by remember { mutableStateOf("http://10.0.2.2:8080") }
  var isChecking by remember { mutableStateOf(false) }
  var serverStatus by remember { mutableStateOf("Bağlantıya Hazır") }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("cloud_connect_lazy_column"),
    contentPadding = PaddingValues(bottom = 96.dp)
  ) {
    // Header
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp)
      ) {
        Text(
          text = "ECOSYSTEM & CLOUD BRIDGE",
          fontSize = 12.sp,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          letterSpacing = 2.sp,
          color = CroowGreen
        )
        Text(
          text = "Croow Cloud Bağlantısı",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
          color = CroowTextMain
        )
        Text(
          text = "Yerel Python sunucunuz ile mobil uygulama arasında köprü kurun.",
          fontSize = 12.sp,
          fontFamily = FontFamily.Monospace,
          color = CroowTextMuted
        )
      }
    }

    // Server Config Card
    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CroowSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              "Python Cloud Server (croow_cloud.py)",
              fontSize = 12.sp,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              color = CroowTextMain
            )
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = Color(0xFF0D2818)
            ) {
              Text(
                ":8080 PORT",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = CroowGreen,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = serverUrl,
            onValueChange = { serverUrl = it },
            label = { Text("Sunucu Adresi (Emülatör: 10.0.2.2:8080)") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = CroowGreen,
              unfocusedBorderColor = CroowBorder,
              focusedTextColor = CroowTextMain,
              unfocusedTextColor = CroowTextMain
            ),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
          )

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              "Durum: $serverStatus",
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              color = if (serverStatus.contains("Hazır") || serverStatus.contains("Aktif")) CroowGreen else CroowTextMuted
            )

            Button(
              onClick = {
                coroutineScope.launch {
                  isChecking = true
                  serverStatus = "Bağlanıyor..."
                  delay(600)
                  serverStatus = "✓ Bağlantı Doğrulandı (Local Vault Aktif)"
                  isChecking = false
                  onShowSnackbar("Croow Cloud köprüsü aktif!")
                }
              },
              shape = RoundedCornerShape(8.dp),
              colors = ButtonDefaults.buttonColors(containerColor = CroowGreen, contentColor = Color.Black)
            ) {
              Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Ping & Senkronize Et", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // Direct App Links Section
    item {
      Column(modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp)) {
        Text(
          "EKOSİSTEM İNDİRMELERİ",
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp,
          color = CroowTextMuted
        )
      }
    }

    // Linux Desktop App Card
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CroowSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 4.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🐧", fontSize = 26.sp)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                "CroowImage-Linux",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = CroowTextMain
              )
              Text(
                "Masaüstü Linux Görüntüleyici & CLI",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = CroowTextMuted
              )
            }
          }

          OutlinedButton(
            onClick = {
              onShowSnackbar("Linux uygulaması /download/CroowImage-Linux adresinde hazır!")
            },
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("İndir", fontSize = 11.sp)
          }
        }
      }
    }

    // Chrome Extension Card
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CroowSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 4.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🧩", fontSize = 26.sp)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                "Chrome Uzantısı (CRW5 Codec)",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = CroowTextMain
              )
              Text(
                "crw-extension.zip • Tarayıcı içi sıkıştırma",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = CroowTextMuted
              )
            }
          }

          OutlinedButton(
            onClick = {
              onShowSnackbar("Chrome Uzantısı /download/crw-extension.zip adresinde hazır!")
            },
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("İndir", fontSize = 11.sp)
          }
        }
      }
    }

    // Format Details Card
    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CroowSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            "📐 .CRW Format Spesifikasyonu",
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = CroowAccentBlue
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            "• Magic Header: CRW4 / CRW5\n" +
            "• Spatial Resolution: uint16 (orig_w, orig_h, base_w, base_h)\n" +
            "• Universal Roots: 255 saturated RGB byte array\n" +
            "• Base Payload: 7-bit RLE index stream (0x80 | run)\n" +
            "• Delta Stream: 0x00 (skip run) + 0x01 (dr, dg, db luminance residuals)",
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 18.sp,
            color = CroowTextMuted
          )
        }
      }
    }
  }
}
