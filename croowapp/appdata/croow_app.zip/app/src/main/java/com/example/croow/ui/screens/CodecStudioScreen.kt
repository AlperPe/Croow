package com.example.croow.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.croow.codec.CompressionResult
import com.example.croow.codec.CroowCodec
import com.example.croow.codec.DecompressionResult
import com.example.croow.data.CroowRepository
import com.example.ui.theme.CroowAccentBlue
import com.example.ui.theme.CroowBorder
import com.example.ui.theme.CroowGreen
import com.example.ui.theme.CroowPurple
import com.example.ui.theme.CroowSurface
import com.example.ui.theme.CroowSurfaceVariant
import com.example.ui.theme.CroowTextMain
import com.example.ui.theme.CroowTextMuted
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

@Composable
fun CodecStudioScreen(
  repository: CroowRepository,
  onShowSnackbar: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  var selectedTab by remember { mutableIntStateOf(0) } // 0: Fold to .CRW, 1: Unfold .CRW

  // Encoder state
  var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
  var targetBaseWidth by remember { mutableIntStateOf(160) }
  var lumThreshold by remember { mutableIntStateOf(22) }
  var compressionResult by remember { mutableStateOf<CompressionResult?>(null) }
  var isProcessing by remember { mutableStateOf(false) }
  var previewReconstructed by remember { mutableStateOf(false) }

  // Presets
  var selectedPreset by remember { mutableStateOf("Dengeli (%95)") }

  // Decoder state
  val vaultItems by repository.vaultItems.collectAsState()
  var decodedResult by remember { mutableStateOf<DecompressionResult?>(null) }

  // Photo Picker
  val photoPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri ->
    if (uri != null) {
      coroutineScope.launch {
        sourceBitmap = loadBitmapFromUri(context, uri)
        compressionResult = null
        previewReconstructed = false
      }
    }
  }

  if (sourceBitmap == null) {
    sourceBitmap = remember {
      repository.createCyberSampleBitmap(
        title = "STUDIO DEMO",
        primaryColor = android.graphics.Color.rgb(0, 230, 118),
        secondaryColor = android.graphics.Color.rgb(88, 166, 255),
        bgColor = android.graphics.Color.rgb(6, 8, 13)
      )
    }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("codec_studio_lazy_column"),
    contentPadding = PaddingValues(bottom = 96.dp)
  ) {
    // Header
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp)
      ) {
        Text(
          text = "SPATIAL CODEC LAB & CODEC BENCHMARK",
          fontSize = 12.sp,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          letterSpacing = 2.sp,
          color = CroowGreen
        )
        Text(
          text = "CRW4 Spatial Image Codec Core",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
          color = CroowTextMain
        )
        Text(
          text = "Spatial base run-length encoding + residual luminance delta.",
          fontSize = 12.sp,
          fontFamily = FontFamily.Monospace,
          color = CroowTextMuted
        )
      }
    }

    // Tabs: Fold / Unfold
    item {
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = CroowSurface,
        contentColor = CroowGreen,
        indicator = { tabPositions ->
          TabRowDefaults.SecondaryIndicator(
            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
            color = CroowGreen
          )
        },
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp)
          .clip(RoundedCornerShape(10.dp))
          .border(1.dp, CroowBorder, RoundedCornerShape(10.dp))
      ) {
        Tab(
          selected = (selectedTab == 0),
          onClick = { selectedTab = 0 },
          text = {
            Text(
              "Fold to .CRW",
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace,
              color = if (selectedTab == 0) CroowGreen else CroowTextMuted
            )
          }
        )
        Tab(
          selected = (selectedTab == 1),
          onClick = { selectedTab = 1 },
          text = {
            Text(
              "Unfold .CRW",
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace,
              color = if (selectedTab == 1) CroowAccentBlue else CroowTextMuted
            )
          }
        )
      }
    }

    // TAB 0: FOLD (ENCODER)
    if (selectedTab == 0) {
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = CroowSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            // Quality Preset Quick Bar
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              val presets = listOf("Dengeli (%95)", "HQ Netlik (%90)", "Ultra Eko (%97)")
              presets.forEach { preset ->
                FilterChip(
                  selected = (selectedPreset == preset),
                  onClick = {
                    selectedPreset = preset
                    when (preset) {
                      "Dengeli (%95)" -> { targetBaseWidth = 160; lumThreshold = 22 }
                      "HQ Netlik (%90)" -> { targetBaseWidth = 256; lumThreshold = 15 }
                      "Ultra Eko (%97)" -> { targetBaseWidth = 128; lumThreshold = 32 }
                    }
                  },
                  label = { Text(preset, fontSize = 11.sp) },
                  colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CroowGreen.copy(alpha = 0.2f),
                    selectedLabelColor = CroowGreen
                  )
                )
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Source Image or Reconstructed Preview
            val displayBmp = if (previewReconstructed && compressionResult != null) {
              compressionResult?.decodedPreview
            } else {
              sourceBitmap
            }

            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(190.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.Black)
                .border(1.dp, CroowBorder, RoundedCornerShape(10.dp)),
              contentAlignment = Alignment.Center
            ) {
              displayBmp?.let { bmp ->
                Image(
                  bitmap = bmp.asImageBitmap(),
                  contentDescription = "Source",
                  modifier = Modifier.fillMaxSize(),
                  contentScale = ContentScale.Fit
                )
              }

              // State Badge
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color(0xCC06080D),
                modifier = Modifier
                  .align(Alignment.BottomEnd)
                  .padding(8.dp)
              ) {
                Text(
                  text = if (previewReconstructed && compressionResult != null) ".CRW Çözülen Görüntü" else "Orijinal Kaynak",
                  fontSize = 10.sp,
                  fontFamily = FontFamily.Monospace,
                  color = if (previewReconstructed) CroowGreen else CroowTextMuted,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              OutlinedButton(
                onClick = {
                  photoPicker.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                  )
                },
                modifier = Modifier.weight(1f)
              ) {
                Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Görsel Seç", fontSize = 11.sp)
              }

              Button(
                onClick = {
                  sourceBitmap?.let { bmp ->
                    coroutineScope.launch {
                      isProcessing = true
                      val res = withContext(Dispatchers.Default) {
                        CroowCodec.compress(
                          srcBitmap = bmp,
                          targetBaseWidth = targetBaseWidth,
                          lumThreshold = lumThreshold
                        )
                      }
                      compressionResult = res
                      previewReconstructed = true
                      isProcessing = false
                      onShowSnackbar("✓ Sıkıştırma Tamamlandı! -%${res.savingsPercent} Tasarruf")
                    }
                  }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CroowGreen, contentColor = Color.Black),
                modifier = Modifier
                  .weight(1.3f)
                  .testTag("btn_fold_crw")
              ) {
                if (isProcessing) {
                  CircularProgressIndicator(color = Color.Black, strokeWidth = 2.dp, modifier = Modifier.size(16.dp))
                } else {
                  Icon(Icons.Default.Compress, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Fold to .CRW", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Custom Tuning Accordion
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = CroowSurfaceVariant,
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Tune, contentDescription = null, tint = CroowAccentBlue, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      "Algoritma İnce Ayarları",
                      fontSize = 11.sp,
                      fontFamily = FontFamily.Monospace,
                      fontWeight = FontWeight.Bold,
                      color = CroowTextMain
                    )
                  }
                  Text("${targetBaseWidth}px / L=$lumThreshold", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = CroowGreen)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Base Width Selector
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text("Base Width: ${targetBaseWidth}px", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = CroowTextMuted)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 2.dp)) {
                  listOf(128, 160, 256).forEach { bw ->
                    FilterChip(
                      selected = (targetBaseWidth == bw),
                      onClick = { targetBaseWidth = bw },
                      label = { Text("${bw}px", fontSize = 10.sp) },
                      colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CroowAccentBlue.copy(alpha = 0.2f),
                        selectedLabelColor = CroowAccentBlue
                      )
                    )
                  }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text("Luminance Threshold:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = CroowTextMuted)
                  Text("$lumThreshold", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = CroowGreen)
                }
                Slider(
                  value = lumThreshold.toFloat(),
                  onValueChange = { lumThreshold = it.roundToInt() },
                  valueRange = 10f..40f
                )
              }
            }
          }
        }
      }

      // Output Card
      item {
        compressionResult?.let { res ->
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = CroowSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CroowGreen),
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 6.dp)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  "⚡ SONUÇ: -%${res.savingsPercent} TASARRUF",
                  fontSize = 13.sp,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold,
                  color = CroowGreen
                )
                Text(
                  "${res.elapsedMs} ms",
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace,
                  color = CroowTextMuted
                )
              }

              Spacer(modifier = Modifier.height(10.dp))

              MetricRow("Orijinal Raw Boyut:", "${res.rawBytesCount / 1024} KB (${res.origWidth}x${res.origHeight})")
              MetricRow("CRW4 Spatial Dosya:", "${res.crwBytesCount / 1024} KB (${res.crwBytesCount} bytes)")
              MetricRow("Görsel Netlik (Fidelity):", "%${res.fidelityPercent}")
              MetricRow("Universal Palette:", "255 Roots Saturated")

              Spacer(modifier = Modifier.height(14.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedButton(
                  onClick = { previewReconstructed = !previewReconstructed },
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.weight(1f)
                ) {
                  Text(if (previewReconstructed) "Orijinale Dön" else "CRW Önizle", fontSize = 11.sp)
                }

                Button(
                  onClick = {
                    coroutineScope.launch {
                      val name = "studio_${System.currentTimeMillis() % 10000}.png"
                      sourceBitmap?.let { repository.compressAndAddToVault(name, it, "Studio") }
                      onShowSnackbar("✓ Sıkıştırılmış dosya başarıyla Kasaya kaydedildi!")
                    }
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = CroowAccentBlue, contentColor = Color.Black),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.weight(1.3f)
                ) {
                  Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(15.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Kasaya Kaydet", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
              }
            }
          }
        }
      }
    }

    // TAB 1: UNFOLD (DECODER)
    if (selectedTab == 1) {
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = CroowSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, CroowBorder),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              "Kasadan .CRW Dosyası Seç:",
              fontSize = 13.sp,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              color = CroowTextMain
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (vaultItems.isEmpty()) {
              Text("Kasada henüz .CRW dosyası yok.", fontSize = 12.sp, color = CroowTextMuted)
            } else {
              vaultItems.take(5).forEach { item ->
                OutlinedButton(
                  onClick = {
                    coroutineScope.launch {
                      val file = File(item.localCrwPath)
                      if (file.exists()) {
                        val bytes = withContext(Dispatchers.IO) { file.readBytes() }
                        decodedResult = withContext(Dispatchers.Default) { CroowCodec.decompress(bytes) }
                        onShowSnackbar("✓ .CRW başarıyla açıldı (${decodedResult?.elapsedMs} ms)")
                      }
                    }
                  },
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(item.name, maxLines = 1, fontSize = 11.sp, color = CroowTextMain)
                    Text("${item.crwSizeKb} KB", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = CroowGreen)
                  }
                }
              }
            }
          }
        }
      }

      // Decoded Output Card
      item {
        decodedResult?.let { dec ->
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = CroowSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, CroowAccentBlue),
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 6.dp)
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                "✓ ÇÖZÜMLENEN GÖRSEL (UNFOLDED)",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = CroowAccentBlue
              )
              Spacer(modifier = Modifier.height(10.dp))

              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(200.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(Color.Black),
                contentAlignment = Alignment.Center
              ) {
                Image(
                  bitmap = dec.bitmap.asImageBitmap(),
                  contentDescription = "Decoded",
                  modifier = Modifier.fillMaxSize(),
                  contentScale = ContentScale.Fit
                )
              }

              Spacer(modifier = Modifier.height(12.dp))

              MetricRow("Çözünürlük:", "${dec.origWidth}x${dec.origHeight}")
              MetricRow("Base Boyut:", "${dec.baseWidth}x${dec.baseHeight}")
              MetricRow("Palet Boyutu:", "${dec.paletteSize} Kök Renk")
              MetricRow("Base Payload:", "${dec.basePayloadSize} bytes")
              MetricRow("Delta Payload:", "${dec.deltaPayloadSize} bytes")
              MetricRow("Çözümleme Süresi:", "${dec.elapsedMs} ms")
            }
          }
        }
      }
    }
  }
}

@Composable
fun MetricRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(label, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = CroowTextMuted)
    Text(value, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = CroowTextMain)
  }
}

private suspend fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
  try {
    context.contentResolver.openInputStream(uri)?.use { stream ->
      BitmapFactory.decodeStream(stream)
    }
  } catch (e: Exception) {
    e.printStackTrace()
    null
  }
}
