package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.model.PlatformFeature

val capabilitiesList = listOf(
  PlatformFeature(
    title = "Gemini AI & Akıllı Yetenekler",
    description = "Uygulamanıza gerçek yapay zeka gücü kazandırın.",
    iconEmoji = "🧠",
    highlights = listOf(
      "Firebase AI Logic ile yerleşik Gemini API entegrasyonu",
      "Akıllı metin üretimi, öneri sistemleri ve sohbet",
      "Görsel ve fotoğraf analizi (Multimodal)",
      "Yapılandırılmış JSON çıktıları ile otomatik veri işleme"
    )
  ),
  PlatformFeature(
    title = "Firebase & Bulut Senkronizasyonu",
    description = "Verileriniz kaybolmasın, cihazlar arası anında eşitlensin.",
    iconEmoji = "☁️",
    highlights = listOf(
      "Cloud Firestore gerçek zamanlı NoSQL veritabanı",
      "Google Sign-In ve güvenli kimlik doğrulama",
      "Çok kullanıcılı paylaşım veya ortak liste desteği",
      "Sıfır güven güvenlik kuralları (Firestore Security Rules)"
    )
  ),
  PlatformFeature(
    title = "Android Cihaz Sensörleri & Donanım",
    description = "Telefonunuzun tüm fiziksel yeteneklerini kullanın.",
    iconEmoji = "📱",
    highlights = listOf(
      "GPS ve canlı konum takibi (FusedLocationProvider)",
      "Fotoğraf seçici ve Kamera (CameraX / PhotoPicker)",
      "Titreşim (Vibration) ve Dokunsal geri bildirim",
      "Adımsayar ve hareket sensörleri"
    )
  ),
  PlatformFeature(
    title = "Modern Jetpack Compose & M3 UI",
    description = "Google'ın en yeni ve akıcı tasarım dili.",
    iconEmoji = "🎨",
    highlights = listOf(
      "Material 3 dinamik renk ve Material You desteği",
      "Otomatik Açık ve Koyu Tema uyumu",
      "Kenardan kenara (Edge-to-Edge) modern tam ekran görünüm",
      "Tablet ve katlanabilir ekranlar için uyarlanabilir tasarım"
    )
  )
)

@Composable
fun CapabilitiesScreen(
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("capabilities_lazy_column"),
    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 96.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header
    item {
      Column {
        Text(
          text = "Neler Yapabilirsiniz?",
          style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "Bu platform ile sıfırdan oluşturabileceğiniz gelişmiş özellikler.",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    // Capability Cards
    items(capabilitiesList) { feature ->
      ElevatedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = feature.iconEmoji, fontSize = 28.sp)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = feature.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = feature.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          feature.highlights.forEach { item ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = item,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 18.sp
              )
            }
          }
        }
      }
    }

    // Prompting Tips Card
    item {
      OutlinedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.outlinedCardColors(
          containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
        ),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.TipsAndUpdates,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "💡 En İyi Sonuç İçin İpuçları",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onSurface
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          TipItem(title = "Net olun:", desc = "'Güzel bir uygulama' yerine 'Koyu temalı, 3 sekmeli bir müzik çalar' deyin.")
          TipItem(title = "Adım adım ilerleyin:", desc = "Önce ana ekranı oluşturun, ardından detayları ve animasyonları ekletin.")
          TipItem(title = "İstediğiniz zaman değiştirin:", desc = "'Şu rengi mavi yap', 'Butonun yerini değiştir' diyerek anında revize edin.")
        }
      }
    }
  }
}

@Composable
fun TipItem(title: String, desc: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    verticalAlignment = Alignment.Top
  ) {
    Text(
      text = "• ",
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.primary
    )
    Column {
      Text(
        text = title,
        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface
      )
      Text(
        text = desc,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}
