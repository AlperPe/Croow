package com.example.croow.model

import android.graphics.Bitmap

data class VaultItem(
  val id: String,
  val name: String,
  val crwFileName: String,
  val origWidth: Int,
  val origHeight: Int,
  val rawSizeKb: Int,
  val crwSizeKb: Int,
  val savingsPercent: Int,
  val fidelityPercent: Float = 95.0f,
  val timestamp: String,
  val category: String = "Genel",
  val isFavorite: Boolean = false,
  val thumbnail: Bitmap?,
  val originalBitmap: Bitmap? = null,
  val localCrwPath: String
)

data class SwarmLogEntry(
  val timestamp: String,
  val message: String,
  val type: LogType = LogType.INFO
)

enum class LogType {
  INFO, SUCCESS, WARNING, HIGHLIGHT
}

data class SwarmStats(
  val totalTrainedImages: Int = 15,
  val avgFidelity: Float = 94.6f,
  val avgSavings: Int = 95,
  val saturatedRootsCount: Int = 255,
  val isRunning: Boolean = false
)

enum class VaultSortOrder {
  DATE_DESC, SAVINGS_DESC, SIZE_DESC, NAME_ASC
}
